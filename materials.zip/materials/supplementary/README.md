# Supplementary experimental details

Companion to **Stage-Wise Physics-Guided Latency Prediction for Resource-Partitioned Hardware-Aware Neural Architecture Search**, TCAD-2026-0638.

## Build

1. Optional: run `python scripts/regenerate_tables.py` from this directory (Python standard library only).
2. Run `pdflatex -interaction=nonstopmode -halt-on-error supplementary.tex` twice.

The checked-in table files allow LaTeX compilation without Python or access to the experiment server. A TeX installation needs IEEEtran's standard dependencies, amsmath, amssymb, booktabs, longtable, array, hyperref, and xurl. `IEEEtran.cls` is included from the original manuscript package.

## Contents

- `supplementary.tex` and `supplementary.pdf`: editable source and compiled supplement.
- `tables/`: four generated LaTeX tables.
- `data/ablation_*.json`: full-precision original corrected ablation exports.
- `data/*holdout_per_cell.csv`: final manuscript operating-cell exports.
- `data/*topk_recall.csv`: preserved Top-K exports.
- `data/*timing_excerpt.txt`: the original collection code's timing expressions, with original line numbers.
- `data/source_provenance.json`: source-file hashes and export mapping.
- `data/verification.json`: recomputed summary checks.
- `MANIFEST_SHA256.csv`: package checksums, excluding the manifest itself.

The document restores detail, not superseded interpretations. It distinguishes the original CPU window-average timing from the later repeated-median counter campaign, flat from stratified correlation, the original six-budget study from the newer HELP/MLP curves, and quota-restricted evaluation from quota extrapolation. Original manuscript prose asserting guaranteed thermal/frequency states was not copied without supporting measurements.
