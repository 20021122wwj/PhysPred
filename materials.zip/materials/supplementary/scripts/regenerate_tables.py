"""Regenerate supplementary tables from the supplied numeric exports."""

from pathlib import Path

import csv, json, statistics

def csv_rows(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def table(path, caption, label, headers, rows, align):
    n = len(headers)
    lines = [r'\begin{longtable}{' + align + '}',
             r'\caption{' + caption + r'}\label{' + label + r'}\\',
             r'\toprule', ' & '.join(headers) + r' \\', r'\midrule', r'\endfirsthead',
             r'\multicolumn{' + str(n) + r'}{c}{Table \thetable\ (continued)}\\',
             r'\toprule', ' & '.join(headers) + r' \\', r'\midrule', r'\endhead',
             r'\midrule\multicolumn{' + str(n) + r'}{r}{Continued on next page}\\',
             r'\endfoot', r'\bottomrule', r'\endlastfoot']
    prev = None
    for row in rows:
        if prev is not None and row[0] != prev:
            lines.append(r'\addlinespace[3pt]')
        lines.append(' & '.join(row) + r' \\')
        prev = row[0]
    lines.append(r'\end{longtable}')
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')

def regenerate(base):
    models = {d:json.loads((base/f'data/ablation_{d}.json').read_text()) for d in ['gpu','amd','intel']}
    names = {'gpu':'RTX 3090','amd':'AMD 4800H','intel':'Intel 125H'}
    rows, checks = [], {}
    for dev in names:
        cells = csv_rows(base/f'data/{dev}_holdout_per_cell.csv')
        topk = csv_rows(base/f'data/{dev}_topk_recall.csv')
        assert len(cells) == (16 if dev == 'gpu' else 12)
        assert len(topk) == 4*len(cells)
        index = {(int(r['batch']),int(r['quota']),int(r['K'])):float(r['recall']) for r in topk}
        for c in sorted(cells,key=lambda r:(int(r['batch']),int(r['quota']))):
            b,q=int(c['batch']),int(c['quota'])
            rows.append([names[dev],str(b),str(q),f"{float(c['mape_percent']):.2f}",f"{float(c['tau']):.3f}"]+
                        [f'{index[b,q,k]:.2f}' for k in [5,10,20,50]])
        for r in models[dev]['study3']:
            quota_cells = [c for c in cells if int(c['quota']) == r['Q']]
            assert abs(statistics.mean(float(c['mape_percent']) for c in quota_cells)-r['hw_mape']) < 1e-10
            assert abs(statistics.mean(float(c['tau']) for c in quota_cells)-r['hw_tau_strat']) < 1e-10
        checks[dev]={'mean_mape':statistics.mean(float(c['mape_percent']) for c in cells),
                     'mean_tau':statistics.mean(float(c['tau']) for c in cells),
                     'mean_top50':statistics.mean(v for (b,q,k),v in index.items() if k==50),
                     'min_top50':min(v for (b,q,k),v in index.items() if k==50)}
    table(base/'tables/operating_cells.tex',
          'Operating-cell errors and Top-$K$ recall on 300 held-out architectures per cell. MAPE is in percent; recall is a fraction. The error exports and Top-$K$ exports are retained as separate records of the same architecture-disjoint evaluation design.',
          'tab:cells',['Device','$b$','$Q$ (\\%)','MAPE','$\\tau_c$','$K=5$','$K=10$','$K=20$','$K=50$'],rows,'lrrrrrrrr')
    rows=[]
    for dev,obj in models.items():
        for r in obj['study1']:
            rows.append([names[dev],str(r['N']),f"{r['hw_mape']:.2f}",f"{r['base_mape']:.2f}",f"{r['hw_tau_strat']:.3f}",f"{r['base_tau_strat']:.3f}"])
    table(base/'tables/sample_efficiency.tex','Original six-budget sample-efficiency study. MAPE is in percent. Each budget counts distinct training architectures; the complete operating grid is measured for each architecture. These are single-support-draw results, not five-repeat means.',
          'tab:samples',['Device','$N$','PhysPred MAPE','FLOPs MAPE','PhysPred $\\tau$','FLOPs $\\tau$'],rows,'lrrrrr')
    rows=[]
    for dev,obj in models.items():
        for r in obj['study2']:
            rows.append([names[dev],{'LGBM-Huber':'LightGBM--Huber','LGBM-MSE':'LightGBM--MSE','RandomForest':'Random Forest','Ridge':'Ridge'}[r['model']],
                         f"{r['mape']:.2f}",f"{r['rmse']:.3f}",f"{r['r2']:.4f}",f"{r['tau_strat']:.3f}"])
    table(base/'tables/backbones.tex','Regression-backbone comparison on the full C4 representation. MAPE is in percent and RMSE in milliseconds; $\\tau$ is stratified. Values are exported from the corrected original study records, without retraining.',
          'tab:backbones',['Device','Regressor','MAPE','RMSE','$R^2$','$\\tau$'],rows,'llrrrr')
    rows=[]
    for dev,obj in models.items():
        for r in obj['study3']:
            rows.append([names[dev],str(r['Q']),f"{r['hw_mape']:.2f}",f"{r['base_mape']:.2f}",f"{r['delta_mape']:+.2f}",f"{r['hw_tau_strat']:.3f}",f"{r['delta_tau_strat']:+.3f}"])
    table(base/'tables/quota_gains.tex','Quota-restricted evaluation of the two mixed-quota predictors in the original ablation campaign. Positive differences favor PhysPred. MAPE is in percent and $\\Delta$MAPE in percentage points (pp).',
          'tab:quotas',['Device','$Q$ (\\%)','PhysPred','FLOPs','$\\Delta$MAPE','$\\tau_{\\rm Phys}$','$\\Delta\\tau$'],rows,'lrrrrrr')
    (base/'data/verification.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')

if __name__ == '__main__':
    regenerate(Path(__file__).resolve().parents[1])
