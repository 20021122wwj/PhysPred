# Original CPU baseline provenance

Source inspected: `D:/PhysPred_Experiment` on 2026-08-25. The source directory was not modified.

## Intel

`intel_exact_original/` is copied verbatim from `scripts/baseline_results_intel/`. Its Protocol A and Protocol B values match the manuscript after rounding.

## AMD

`amd_saved_legacy/` is copied from `scripts/baseline_results_cpu/`, but it does not match the manuscript and must not be cited as the Table III AMD source.

`amd_reproduced_torch_2_2_2/` was generated from the recovered `dataset_cpu_amd.pkl` and `baseline_comparison_cpu1.py` with Python 3.10, torch 2.2.2+cpu, and LightGBM 4.5.0. FLOPs-only and PhysPred reproduce the manuscript after rounding. BRP-NAS and the supervised MLP do not reproduce the submitted neural-network values exactly.

`scripts_and_datasets/` contains verbatim copies of the recovered inputs and code. The original requirements specify only `torch>=2.0.0`; they do not lock the exact PyTorch build. No new latency measurement was performed.

