"""
worst_case_topk.py  —  FIXED VERSION

Critical fixes:
  [FIX-3] HW-Aware feature now matches the main model exactly:
          last CPU feature = total_act_footprint (NOT total_act / n_active).
          Previous version's feature mismatch meant Table IV was not computed
          from the same model as Table I.
  [FIX-2] Training uses proper inner val split (no test-set leakage).
  [FIX-15] Top-K recall now uses rankdata(method='min') to handle ties.

Usage:
    python worst_case_topk.py --data dataset_gpu_hybrid.pkl   --platform gpu
    python worst_case_topk.py --data dataset_cpu_amd.pkl      --platform cpu
    python worst_case_topk.py --data dataset_cpu_intel.pkl    --platform cpu
"""
import argparse
import pickle
import warnings
import numpy as np
import lightgbm as lgb
from collections import defaultdict
from scipy.stats import rankdata
from sklearn.model_selection import GroupShuffleSplit

warnings.filterwarnings("ignore")

STAGE_CONFIGS = [
    (16,  24,  2),
    (24,  40,  2),
    (40,  80,  2),
    (80, 112,  1),
    (112, 160, 2),
]

N_SM_GPU = 82
ALIGN_GPU = 16
BYTES_PER_ELEM_GPU = 2

N_CORES_MAX_CPU = 4.0
ALIGN_CPU = 8
BYTES_PER_ELEM_CPU = 4

LGBM_PARAMS_GPU = dict(
    objective='huber', alpha=1.2, n_estimators=4000, learning_rate=0.005,
    num_leaves=63, min_child_samples=8, subsample=0.8, colsample_bytree=0.8,
    random_state=2026, verbose=-1,
)
LGBM_PARAMS_CPU = dict(
    objective='huber', alpha=1.2, n_estimators=4500, learning_rate=0.005,
    num_leaves=63, min_child_samples=8, subsample=0.8, colsample_bytree=0.8,
    random_state=2026, verbose=-1,
)


def align(c, a):
    return a * ((c + a - 1) // a)


def extract_hw_aware_gpu(ks, e, d, batch, q):
    """38-dim GPU feature vector — matches train_eval.py exactly."""
    n_sm_effective = N_SM_GPU * (q / 100.0)
    total_depth = sum(d)
    big_k_count = 0
    feats = [float(batch), float(q) / 100.0, float(n_sm_effective),
             float(total_depth), 0.0]  # placeholder

    total_pw = total_dw = total_bytes = 0.0
    curr_res, ptr = 112, 0
    for s, di in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[s]
        s_pw = s_dw = s_b = 0.0
        for i in range(di):
            k, ev = ks[ptr + i], e[ptr + i]
            mid = align(int(in_c * ev), ALIGN_GPU)
            ic_a = align(in_c, ALIGN_GPU)
            oc_a = align(out_c, ALIGN_GPU)
            st = stride if i == 0 else 1
            nr = curr_res // st
            if k > 3:
                big_k_count += 1
            pw = 2 * curr_res * curr_res * ic_a * mid + \
                 2 * nr * nr * mid * oc_a
            dw = 2 * nr * nr * k * k * mid
            traffic = BYTES_PER_ELEM_GPU * (
                curr_res * curr_res * ic_a + ic_a * mid +
                k * k * mid + mid * oc_a + nr * nr * oc_a +
                2 * curr_res * curr_res * mid)
            s_pw += pw * batch
            s_dw += dw * batch
            s_b  += traffic * batch
            in_c, curr_res = out_c, nr
        ptr += 4
        i_pw = s_pw / max(s_b, 1.0)
        i_dw = s_dw / max(s_b, 1.0)
        feats.extend([float(di), s_pw, s_dw, s_b, i_pw, i_dw])
        total_pw += s_pw
        total_dw += s_dw
        total_bytes += s_b
    feats[4] = float(big_k_count)
    feats.extend([total_pw, total_dw, total_bytes])
    return feats


def extract_hw_aware_cpu(ks, e, d, batch, q):
    """
    [FIX-3] 32-dim CPU feature vector — now matches cpu_train_eval.py EXACTLY.
    Previous version divided by n_active at the end; this version uses the
    raw total activation footprint, as in the main model.
    """
    n_active = N_CORES_MAX_CPU * (q / 100.0)
    total_depth = sum(d)
    feats = [float(batch), float(n_active), float(total_depth)]

    total_pw = total_dw = total_bytes = total_act = 0.0
    curr_res, ptr = 112, 0
    for s, di in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[s]
        s_pw = s_dw = s_b = s_foot = 0.0
        for i in range(di):
            k, ev = ks[ptr + i], e[ptr + i]
            mid = align(int(in_c * ev), ALIGN_CPU)
            ic_a = align(in_c, ALIGN_CPU)
            oc_a = align(out_c, ALIGN_CPU)
            st = stride if i == 0 else 1
            nr = curr_res // st
            pw = 2 * curr_res * curr_res * ic_a * mid + \
                 2 * nr * nr * mid * oc_a
            dw = 2 * nr * nr * k * k * mid
            traffic = BYTES_PER_ELEM_CPU * (
                curr_res * curr_res * ic_a + ic_a * mid +
                k * k * mid + mid * oc_a + nr * nr * oc_a +
                2 * curr_res * curr_res * mid)
            act = BYTES_PER_ELEM_CPU * (curr_res * curr_res * mid +
                                        nr * nr * oc_a)
            s_pw += pw * batch
            s_dw += dw * batch
            s_b  += traffic * batch
            s_foot += act * batch
            in_c, curr_res = out_c, nr
        ptr += 4
        foot_per_core = s_foot / (n_active + 1e-5)
        feats.extend([float(di), s_pw, s_dw, s_b, foot_per_core])
        total_pw += s_pw
        total_dw += s_dw
        total_bytes += s_b
        total_act += s_foot
    # [FIX-3] Use raw total_act (not total_act / n_active)
    feats.extend([total_pw, total_dw, total_bytes, total_act])
    return feats


def prepare_rows(data):
    rows = []
    for arch_idx, s in enumerate(data):
        for (b, q), lat in s["latency_grid"].items():
            if lat <= 0:
                continue
            rows.append({
                "arch_idx": arch_idx,
                "ks": s["ks"], "e": s["e"], "d": s["d"],
                "batch": b, "quota": q, "latency": lat,
            })
    return rows


def build_feature_matrix(rows, platform):
    extractor = extract_hw_aware_gpu if platform == "gpu" else extract_hw_aware_cpu
    X, y, arch_ids, batches, quotas = [], [], [], [], []
    for r in rows:
        X.append(extractor(r["ks"], r["e"], r["d"], r["batch"], r["quota"]))
        y.append(r["latency"])
        arch_ids.append(r["arch_idx"])
        batches.append(r["batch"])
        quotas.append(r["quota"])
    return (np.array(X, dtype=np.float64),
            np.array(y, dtype=np.float64),
            np.array(arch_ids, dtype=np.int32),
            np.array(batches, dtype=np.int32),
            np.array(quotas, dtype=np.int32))


def compute_topk_recall(y_true_cell, y_pred_cell, arch_ids_cell, K):
    """
    [FIX-15] Use stable ranking for Top-K to handle ties consistently.
    Top-K recall = |top-K-by-truth ∩ top-K-by-prediction| / K.
    """
    seen = set()
    y_t, y_p, aids = [], [], []
    for i, a in enumerate(arch_ids_cell):
        if a not in seen:
            seen.add(a)
            y_t.append(y_true_cell[i])
            y_p.append(y_pred_cell[i])
            aids.append(a)
    if len(y_t) < K:
        return None
    y_t = np.array(y_t)
    y_p = np.array(y_p)
    # Use stable rank-based top-K
    rank_true = rankdata(y_t, method='ordinal')   # 1..N ascending
    rank_pred = rankdata(y_p, method='ordinal')
    top_k_true = set(np.where(rank_true <= K)[0].tolist())
    top_k_pred = set(np.where(rank_pred <= K)[0].tolist())
    return len(top_k_true & top_k_pred) / float(K)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--platform", choices=["gpu", "cpu"], required=True)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    print(f"Loading {args.data} (platform = {args.platform}) ...")
    with open(args.data, "rb") as f:
        data = pickle.load(f)
    print(f"  architectures: {len(data)}")

    arch_indices = np.arange(len(data))
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=args.seed)
    tr_arch_idx, te_arch_idx = next(gss.split(arch_indices, groups=arch_indices))
    tr_arch = set(tr_arch_idx.tolist())
    te_arch = set(te_arch_idx.tolist())
    print(f"  train archs: {len(tr_arch)}   test archs: {len(te_arch)}")

    rows_all = prepare_rows(data)
    print(f"  total triplets: {len(rows_all)}")

    rows_tr = [r for r in rows_all if r["arch_idx"] in tr_arch]
    rows_te = [r for r in rows_all if r["arch_idx"] in te_arch]
    print(f"  train triplets: {len(rows_tr)}   test triplets: {len(rows_te)}")

    X_tr, y_tr, aid_tr, _, _ = build_feature_matrix(rows_tr, args.platform)
    X_te, y_te, aid_te, b_te, q_te = build_feature_matrix(rows_te, args.platform)

    # [FIX-2] Proper arch-level inner val split
    tr_arch_arr = np.array(sorted(tr_arch))
    np.random.seed(2025)
    np.random.shuffle(tr_arch_arr)
    n_val = int(len(tr_arch_arr) * 0.15)
    val_archs = set(tr_arch_arr[:n_val].tolist())
    tr_mask  = np.array([a not in val_archs for a in aid_tr])
    val_mask = np.array([a in  val_archs for a in aid_tr])

    print(f"\n  inner split: train triplets={tr_mask.sum()}, val triplets={val_mask.sum()}")
    print(f"  (arch-level: {len(tr_arch)-n_val} train, {n_val} val)")

    print("\nTraining HW-Aware predictor ...")
    params = LGBM_PARAMS_GPU if args.platform == "gpu" else LGBM_PARAMS_CPU
    model = lgb.LGBMRegressor(**params)
    model.fit(X_tr[tr_mask], np.log1p(y_tr[tr_mask]),
              eval_set=[(X_tr[val_mask], np.log1p(y_tr[val_mask]))],
              callbacks=[lgb.early_stopping(400, verbose=False)])
    print(f"  best_iteration = {model.best_iteration_}")

    y_pred_te = np.expm1(model.predict(X_te))

    cells = defaultdict(list)
    for i in range(len(y_te)):
        cells[(b_te[i], q_te[i])].append(i)

    print(f"\nOperating cells found: {sorted(cells.keys())}")
    print(f"Architectures per cell: "
          f"{[len(v) for v in cells.values()][:4]}...")

    print("\n" + "=" * 80)
    print(f"  Top-K Recall — Per-Cell Statistics ({args.platform.upper()})")
    print("=" * 80)
    print(f"  {'K':>4} | {'Mean':>8} | {'Worst':>8} | {'Worst-cell (B,Q)':>20}")
    print("  " + "-" * 60)

    results = {}
    for K in [5, 10, 20, 50]:
        per_cell = {}
        for (b, q), idxs in cells.items():
            yt = y_te[idxs]
            yp = y_pred_te[idxs]
            aids = aid_te[idxs]
            r = compute_topk_recall(yt, yp, aids, K)
            if r is not None:
                per_cell[(b, q)] = r
        if not per_cell:
            continue
        values = list(per_cell.values())
        mean_r = float(np.mean(values))
        worst_cell = min(per_cell, key=per_cell.get)
        worst_r = per_cell[worst_cell]
        print(f"  {K:>4} | {mean_r:>7.3f}  | {worst_r:>7.3f}  | "
              f"(B={worst_cell[0]:>2}, Q={worst_cell[1]:>3}%)")
        results[K] = (mean_r, worst_r, worst_cell, per_cell)

    print("=" * 80)

    # Save full per-cell Top-K for paper table
    import pandas as pd
    rows_out = []
    for K, (mean_r, worst_r, worst_cell, per_cell) in results.items():
        for (b, q), r in per_cell.items():
            rows_out.append({'K': K, 'batch': b, 'quota': q, 'recall': r})
    out_csv = f"topk_recall_{args.platform}.csv"
    pd.DataFrame(rows_out).to_csv(out_csv, index=False)
    print(f"\n✅ Per-cell Top-K recall → {out_csv}")

    print("\nPaper Table IV (paste):")
    for K in [5, 10, 20, 50]:
        if K in results:
            mean_r, worst_r, _, _ = results[K]
            print(f"  K={K:>2}: Mean={mean_r:.2f}  Worst={worst_r:.2f}")


if __name__ == "__main__":
    main()