"""
baseline_models.py  —  FIXED VERSION
Shared PyTorch baseline predictors (BRP-NAS ChainGCN, HELP-MLP).

Critical fixes:
  [FIX-5] encode_node_features no longer overwrites stride with resolution;
          NODE_FEAT_DIM = 10 (stride and resolution are both kept)
  [FIX-A] Added pairwise ranking loss support for BRP-NAS (faithful to original)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

MAX_BLOCKS    = 20
NODE_FEAT_DIM = 10   # [FIX-5] k_onehot(3) + e_onehot(3) + in_c + out_c + stride + res


# ============================================================
#  BRP-NAS style GCN on OFA-MBv3 chain
# ============================================================
class ChainGCN(nn.Module):
    def __init__(self, node_in=NODE_FEAT_DIM, global_in=2,
                 hidden=96, num_layers=3):
        super().__init__()
        self.node_proj = nn.Linear(node_in, hidden)
        self.gcn = nn.ModuleList([nn.Linear(hidden, hidden) for _ in range(num_layers)])
        self.ln  = nn.ModuleList([nn.LayerNorm(hidden)      for _ in range(num_layers)])
        self.head = nn.Sequential(
            nn.Linear(hidden * 2 + global_in, 64),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(64, 1),
        )

    def forward(self, X, mask, g):
        m = mask.unsqueeze(-1)
        h = self.node_proj(X) * m

        for layer, ln in zip(self.gcn, self.ln):
            h_left  = F.pad(h[:, :-1], (0, 0, 1, 0))
            h_right = F.pad(h[:,  1:], (0, 0, 0, 1))
            m_left  = F.pad(mask[:, :-1].unsqueeze(-1), (0, 0, 1, 0))
            m_right = F.pad(mask[:,  1:].unsqueeze(-1), (0, 0, 0, 1))
            deg     = m + m_left + m_right + 1e-6
            h_agg   = (h * m + h_left * m_left + h_right * m_right) / deg
            h       = ln(F.gelu(layer(h_agg))) * m

        # graph-level pooling: mean + max
        # [FIX-16] use -1e9 instead of -1e4 for numerical safety
        h_masked_for_max = h.masked_fill(m == 0, -1e9)
        pooled_max, _    = h_masked_for_max.max(dim=1)
        pooled_mean      = h.sum(dim=1) / (m.sum(dim=1) + 1e-6)
        pooled           = torch.cat([pooled_max, pooled_mean], dim=-1)

        return self.head(torch.cat([pooled, g], dim=-1)).squeeze(-1)


# ============================================================
#  HELP-style MLP
# ============================================================
class HELPMLP(nn.Module):
    def __init__(self, arch_in=125, global_in=2, hidden=256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(arch_in + global_in, hidden),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden, hidden),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x_flat, g):
        return self.net(torch.cat([x_flat, g], dim=-1)).squeeze(-1)


# ============================================================
# [FIX-A] Pairwise ranking loss for BRP-NAS (faithful to original paper)
# ============================================================
def pairwise_ranking_loss(pred, target, margin=0.0):
    """
    BRP-NAS original loss. All (i, j) pairs should have their predicted
    ordering match the ground-truth ordering.
    """
    n = pred.shape[0]
    if n < 2:
        return torch.tensor(0.0, device=pred.device, requires_grad=True)
    i, j = torch.triu_indices(n, n, offset=1, device=pred.device)
    target_sign = torch.sign(target[i] - target[j])
    pred_diff   = pred[i] - pred[j]
    loss = torch.clamp(margin - pred_diff * target_sign, min=0)
    return loss.mean()


# ============================================================
# Architecture encoders
# ============================================================
def encode_node_features(ks, e, d, stage_configs, input_res=224):
    """
    [FIX-5] Produce [MAX_BLOCKS, 10] node-feature tensor + active mask.
    Old version overwrote stride with resolution; now both are kept.
    """
    X    = [[0.0] * NODE_FEAT_DIM for _ in range(MAX_BLOCKS)]
    mask = [0.0] * MAX_BLOCKS

    curr_res, ptr = input_res, 0
    out_idx       = 0
    for stage_idx, depth_i in enumerate(d):
        in_c, out_c, stage_stride = stage_configs[stage_idx]
        for i in range(depth_i):
            k_val, e_val  = ks[ptr + i], e[ptr + i]
            this_stride   = stage_stride if i == 0 else 1
            next_res      = curr_res // this_stride

            feat = [
                1.0 if k_val == 3 else 0.0,
                1.0 if k_val == 5 else 0.0,
                1.0 if k_val == 7 else 0.0,
                1.0 if e_val == 3 else 0.0,
                1.0 if e_val == 4 else 0.0,
                1.0 if e_val == 6 else 0.0,
                in_c  / 160.0,
                out_c / 160.0,
                float(this_stride),       # [FIX-5] stride preserved
                curr_res / 224.0,         # [FIX-5] resolution added
            ]
            X[out_idx]    = feat
            mask[out_idx] = 1.0
            in_c, curr_res = out_c, next_res
            out_idx += 1
        ptr += 4
    return X, mask


def encode_flat_features(ks, e, d):
    feats = [di / 4.0 for di in d]
    ptr = 0
    ks_flat, e_flat = [], []
    for di in d:
        for i in range(4):
            if i < di:
                k_val, e_val = ks[ptr + i], e[ptr + i]
                ks_flat.extend([1.0 if k_val == 3 else 0.0,
                                1.0 if k_val == 5 else 0.0,
                                1.0 if k_val == 7 else 0.0])
                e_flat.extend ([1.0 if e_val == 3 else 0.0,
                                1.0 if e_val == 4 else 0.0,
                                1.0 if e_val == 6 else 0.0])
            else:
                ks_flat.extend([0.0, 0.0, 0.0])
                e_flat.extend ([0.0, 0.0, 0.0])
        ptr += 4
    feats.extend(ks_flat)
    feats.extend(e_flat)
    return feats  # total 125