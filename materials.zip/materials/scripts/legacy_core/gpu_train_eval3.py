import os
import pickle
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_absolute_percentage_error, r2_score
from scipy.stats import kendalltau
import joblib
import warnings

warnings.filterwarnings("ignore")

DATASET_FILE = "dataset_gpu_hybrid.pkl"
MODEL_SAVE_PATH = "gpu_predictor_roofline_v4_matrix.pkl"

# Hardware-aware feature construction
def extract_tensor_core_features(ks, e, d, batch, resource_percent):
    """
    1. 彻底修复真实的 MACs (FLOPs) 与访存 Bytes 理论计算公式。
    2. 将 Pointwise(Tensor Core) 和 Depthwise(CUDA Core) 的算力物理剥离！
    """
    res_ratio = resource_percent / 100.0
    active_sms = 82.0 * res_ratio  

    base_stage_configs = [
        {"in_c": 16, "out_c": 24, "stride": 2},   
        {"in_c": 24, "out_c": 40, "stride": 2},   
        {"in_c": 40, "out_c": 80, "stride": 2},   
        {"in_c": 80, "out_c": 112, "stride": 1},  
        {"in_c": 112, "out_c": 160, "stride": 2}, 
    ]

    curr_res = 112
    ptr = 0
    
    total_depth = sum(d)
    large_kernel_count = sum(1 for k in ks if k > 3)
    
    features = [batch, res_ratio, active_sms, total_depth, large_kernel_count]
    
    total_pw_flops = 0
    total_dw_flops = 0
    total_bytes = 0

    for stage_idx, depth in enumerate(d):
        stage_pw_flops = 0
        stage_dw_flops = 0
        stage_bytes = 0
        
        config = base_stage_configs[stage_idx]
        in_c = config["in_c"]
        out_c = config["out_c"]
        stride = config["stride"]

        for i in range(depth):
            k_val = ks[ptr + i]
            e_val = e[ptr + i]

            mid_c = int(in_c * e_val)
            
            mid_c_align = ((mid_c + 7) // 8) * 8
            in_c_align = ((in_c + 7) // 8) * 8
            out_c_align = ((out_c + 7) // 8) * 8

            this_stride = stride if i == 0 else 1
            next_res = curr_res // this_stride

            # 真实的乘加次数 (MACs) 理论公式
            mac_exp = (curr_res ** 2) * in_c_align * mid_c_align
            mac_dw = (next_res ** 2) * (k_val ** 2) * mid_c_align
            mac_proj = (next_res ** 2) * mid_c_align * out_c_align

            # 物理剥离特征
            pw_flops = (mac_exp + mac_proj) * 2.0 * batch
            dw_flops = mac_dw * 2.0 * batch

            # 真实的显存访存量 (Memory Traffic)
            mem_read_in = (curr_res ** 2) * in_c_align
            mem_read_w = (in_c_align * mid_c_align) + (k_val ** 2 * mid_c_align) + (mid_c_align * out_c_align)
            mem_write_out = (next_res ** 2) * out_c_align
            mem_inter_act = (curr_res ** 2) * mid_c_align 
            
            bytes_accessed = (mem_read_in + mem_read_w + mem_write_out + mem_inter_act * 2) * batch * 2.0

            stage_pw_flops += pw_flops
            stage_dw_flops += dw_flops
            stage_bytes += bytes_accessed  

            in_c = out_c  
            curr_res = next_res

        ptr += 4  
        
        stage_pw_intensity = stage_pw_flops / (stage_bytes + 1e-5)
        stage_dw_intensity = stage_dw_flops / (stage_bytes + 1e-5)
        
        features.extend([
            depth, 
            stage_pw_flops,   
            stage_dw_flops,   
            stage_bytes, 
            stage_pw_intensity,
            stage_dw_intensity
        ])
        
        total_pw_flops += stage_pw_flops
        total_dw_flops += stage_dw_flops
        total_bytes += stage_bytes

    features.extend([total_pw_flops, total_dw_flops, total_bytes])

    return features

# Data loading and architecture-disjoint OOD split
print("[GPU] Building hardware-aware latency predictor...")

with open(DATASET_FILE, "rb") as f: 
    data = pickle.load(f)

X_list, Y_list, group_list, meta_list = [], [], [], []

for arch_idx, sample in enumerate(data):
    ks, e, d = sample['ks'], sample['e'], sample['d']
    for (batch, res), latency in sample['latency_grid'].items():
        if latency > 0:
            fine_grained_feats = extract_tensor_core_features(ks, e, d, batch, res)
            X_list.append(fine_grained_feats)
            Y_list.append(latency)
            group_list.append(arch_idx)  
            meta_list.append({'batch': batch, 'res': res, 'arch_idx': arch_idx})

X = np.array(X_list)
Y = np.array(Y_list)
groups = np.array(group_list)
Y_log = np.log1p(Y)

gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
train_idx, test_idx = next(gss.split(X, Y_log, groups))

X_train, y_train = X[train_idx], Y_log[train_idx]
X_test, y_test = X[test_idx], Y_log[test_idx]
meta_test = [meta_list[i] for i in test_idx]

# Predictor training
model = lgb.LGBMRegressor(
    objective='huber',
    alpha=1.2,
    n_estimators=4000,       
    learning_rate=0.005,     
    num_leaves=63,           
    min_child_samples=8,     
    subsample=0.8, 
    colsample_bytree=0.8, 
    random_state=2026, 
    verbose=-1
)

model.fit(
    X_train, y_train, 
    eval_set=[(X_test, y_test)], 
    callbacks=[lgb.early_stopping(400, verbose=False)]
)

y_pred_log = model.predict(X_test)
y_pred = np.expm1(y_pred_log)
y_true = np.expm1(y_test)

# Evaluation results
overall_mape = mean_absolute_percentage_error(y_true, y_pred) * 100
overall_r2 = r2_score(y_true, y_pred)

print("\n" + "=" * 65)
print(f"🏆 Table X: Hardware-Aware 物理模型 - 全局泛化性能评估")
print(f"   ➤ 完全未见网络 (Unseen) : {len(np.unique(groups[test_idx]))} 个")
print(f"   ➤ 全局 MAPE             : {overall_mape:.2f}%")
print(f"   ➤ 全局 R2               : {overall_r2:.4f}")
print("-" * 65)

grid_results = {}
for i, meta in enumerate(meta_test):
    b, r = meta['batch'], meta['res']
    if (b, r) not in grid_results:
        grid_results[(b, r)] = {'true': [], 'pred': []}
    grid_results[(b, r)]['true'].append(y_true[i])
    grid_results[(b, r)]['pred'].append(y_pred[i])

batches = [1, 8, 16, 32]
quotas = [10, 25, 50, 100]

print("📈 Table Y: MAPE Error Matrix (%) by Batch and SM Quota")
header = "| Batch \\ Quota | " + " | ".join([f"{q:3d}%" for q in quotas]) + " |"
print(header)
print("| :--- | " + " | ".join([":---:" for _ in quotas]) + " |")
for b in batches:
    row = f"| **{b:2d}** | "
    for q in quotas:
        if (b, q) in grid_results:
            t = np.array(grid_results[(b, q)]['true'])
            p = np.array(grid_results[(b, q)]['pred'])
            cell_mape = mean_absolute_percentage_error(t, p) * 100
            row += f"{cell_mape:5.2f} | "
        else:
            row += " N/A | "
    print(row)

print("-" * 65)
print("🥇 Table Z: NAS 排名一致性 (Kendall's Tau Matrix)")
header_tau = "| Batch \\ Quota | " + " | ".join([f"{q:3d}%" for q in quotas]) + " |"
print(header_tau)
print("| :--- | " + " | ".join([":---:" for _ in quotas]) + " |")

global_taus = []
for b in batches:
    row = f"| **{b:2d}** | "
    for q in quotas:
        if (b, q) in grid_results:
            t = np.array(grid_results[(b, q)]['true'])
            p = np.array(grid_results[(b, q)]['pred'])
            tau, _ = kendalltau(t, p)
            if not np.isnan(tau): 
                row += f"{tau:5.4f} | "
                global_taus.append(tau)
            else:
                row += "  N/A  | "
        else:
            row += "  N/A  | "
    print(row)

print(f"\n   🚀 Global Stratified Kendall's Tau: {np.mean(global_taus):.4f}")
print("=" * 65)

joblib.dump(model, MODEL_SAVE_PATH)
