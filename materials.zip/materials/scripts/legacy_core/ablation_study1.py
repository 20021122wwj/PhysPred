"""
ablation_study.py  —  FIXED VERSION

Critical fixes:
  [FIX-1]  τ metric throughout uses per-cell mean (paper §III.D definition).
  [FIX-2]  Inner val split for LightGBM (no test-set leakage).
  [FIX-4]  Study 1 N-list uses the true max (train-set size); N=1500
           asymptote reported as a separate "full-data no-holdout" point.
  [FIX-7]  Ridge preprocessing selectively log-transforms only large-scale
           columns, preserving small-integer feature semantics.
  [FIX-3]  Fold-level std reported for all ablation results.

Usage:
    python ablation_study.py --device gpu   --dataset dataset_gpu_hybrid.pkl
    python ablation_study.py --device amd   --dataset dataset_cpu_amd.pkl
    python ablation_study.py --device intel --dataset dataset_cpu_intel.pkl

Optional: provide --n_trees to skip CV-based estimation.
"""

import argparse, pickle, warnings
import numpy as np
import pandas as pd
import lightgbm as lgb
from collections import defaultdict
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold, GroupShuffleSplit
from sklearn.metrics import mean_absolute_percentage_error, r2_score
from scipy.stats import kendalltau

warnings.filterwarnings("ignore")

STAGE_CONFIGS = [(16,24,2),(24,40,2),(40,80,2),(80,112,1),(112,160,2)]
SM_COUNT = 82

BASE_LGBM = dict(learning_rate=0.005, num_leaves=63, min_child_samples=8,
                 subsample=0.8, colsample_bytree=0.8, random_state=2026, verbose=-1)

_align16 = lambda c: ((c+15)//16)*16
_align8  = lambda c: ((c+7)//8)*8


# ============================================================
# [FIX-1] Stratified τ: per-cell mean
# ============================================================
def stratified_kendall_tau(y_true, y_pred, meta):
    grid = defaultdict(lambda: {'t': [], 'p': []})
    for i, m in enumerate(meta):
        grid[(m['batch'], m['res'])]['t'].append(y_true[i])
        grid[(m['batch'], m['res'])]['p'].append(y_pred[i])
    taus = []
    for v in grid.values():
        if len(v['t']) < 2:
            continue
        tau, _ = kendalltau(v['t'], v['p'])
        if not np.isnan(tau):
            taus.append(tau)
    return float(np.mean(taus)) if taus else np.nan


def inner_val_split(tr_idx, groups, val_frac=0.15, random_state=2025):
    """[FIX-2] Arch-level inner val split."""
    gss = GroupShuffleSplit(n_splits=1, test_size=val_frac, random_state=random_state)
    X_dummy = np.zeros(len(tr_idx))
    g_tr = groups[tr_idx]
    inner_tr, inner_val = next(gss.split(X_dummy, X_dummy, g_tr))
    return tr_idx[inner_tr], tr_idx[inner_val]


# ============================================================
# Feature extractors C1-C4 (unchanged)
# ============================================================
def extract_c1(ks, e, d, batch, resource_percent, device):
    active = resource_percent/100.0 if device=="gpu" else 4.0*resource_percent/100.0
    flops, res, ptr = 0.0, 112, 0
    for si, depth_i in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[si]
        for i in range(depth_i):
            k, ev = ks[ptr+i], e[ptr+i]
            mid = int(in_c*ev); s = stride if i==0 else 1; nr = res//s
            flops += (2*res**2*in_c*mid + 2*nr**2*k**2*mid + 2*nr**2*mid*out_c)*batch
            in_c = out_c; res = nr
        ptr += 4
    return [np.log1p(flops), float(batch), active]


def extract_c2(ks, e, d, batch, resource_percent, device):
    if device == "gpu":
        rr = resource_percent/100.0
        act_k, p2 = [], 0
        for di in d:
            for i in range(di): act_k.append(ks[p2+i])
            p2 += 4
        feats = [float(batch), rr, SM_COUNT*rr, float(sum(d)),
                 float(sum(1 for k in act_k if k>3))]
    else:
        feats = [float(batch), 4.0*resource_percent/100.0, float(sum(d))]
    tot_pw, tot_dw, res, ptr = 0.0, 0.0, 112, 0
    for si, depth_i in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[si]
        s_pw = s_dw = 0.0
        for i in range(depth_i):
            k, ev = ks[ptr+i], e[ptr+i]
            mid = int(in_c*ev); s = stride if i==0 else 1; nr = res//s
            s_pw += (res**2*in_c*mid + nr**2*mid*out_c)*2.0*batch
            s_dw += nr**2*k**2*mid*2.0*batch
            in_c = out_c; res = nr
        ptr += 4
        feats.extend([float(depth_i), s_pw, s_dw])
        tot_pw += s_pw; tot_dw += s_dw
    feats.extend([tot_pw, tot_dw])
    return feats


def extract_c3(ks, e, d, batch, resource_percent, device):
    if device == "gpu":
        rr = resource_percent/100.0
        act_k, p2 = [], 0
        for di in d:
            for i in range(di): act_k.append(ks[p2+i])
            p2 += 4
        feats = [float(batch), rr, SM_COUNT*rr, float(sum(d)),
                 float(sum(1 for k in act_k if k>3))]
        align, bw = _align16, 2.0
    else:
        feats = [float(batch), 4.0*resource_percent/100.0, float(sum(d))]
        align, bw = _align8, 4.0
    tot_pw = tot_dw = tot_bytes = tot_fp = 0.0
    res, ptr = 112, 0
    for si, depth_i in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[si]
        s_pw = s_dw = s_bytes = s_fp = 0.0
        for i in range(depth_i):
            k, ev = ks[ptr+i], e[ptr+i]
            mid = int(in_c*ev)
            ma, ia, oa = align(mid), align(in_c), align(out_c)
            s = stride if i==0 else 1; nr = res//s
            s_pw += (res**2*ia*ma + nr**2*ma*oa)*2.0*batch
            s_dw += nr**2*k**2*ma*2.0*batch
            s_bytes += (res**2*ia + ia*ma + k**2*ma + ma*oa +
                        nr**2*oa + res**2*ma*2)*batch*bw
            s_fp += (res**2*ma + nr**2*oa)*batch*bw
            in_c = out_c; res = nr
        ptr += 4
        feats.extend([float(depth_i), s_pw, s_dw, s_bytes])
        tot_pw += s_pw; tot_dw += s_dw; tot_bytes += s_bytes; tot_fp += s_fp
    feats.extend([tot_pw, tot_dw, tot_bytes])
    if device != "gpu":
        feats.append(tot_fp)
    return feats


def extract_c4(ks, e, d, batch, resource_percent, device):
    if device == "gpu":
        rr = resource_percent/100.0
        act_k, p2 = [], 0
        for di in d:
            for i in range(di): act_k.append(ks[p2+i])
            p2 += 4
        feats = [float(batch), rr, SM_COUNT*rr, float(sum(d)),
                 float(sum(1 for k in act_k if k>3))]
        align, bw = _align16, 2.0
    else:
        ac = 4.0*resource_percent/100.0
        feats = [float(batch), ac, float(sum(d))]
        align, bw = _align8, 4.0
        ac_eps = ac + 1e-5
    tot_pw = tot_dw = tot_bytes = tot_fp = 0.0
    res, ptr = 112, 0
    for si, depth_i in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[si]
        s_pw = s_dw = s_bytes = s_fp = 0.0
        for i in range(depth_i):
            k, ev = ks[ptr+i], e[ptr+i]
            mid = int(in_c*ev)
            ma, ia, oa = align(mid), align(in_c), align(out_c)
            s = stride if i==0 else 1; nr = res//s
            s_pw += (res**2*ia*ma + nr**2*ma*oa)*2.0*batch
            s_dw += nr**2*k**2*ma*2.0*batch
            s_bytes += (res**2*ia + ia*ma + k**2*ma + ma*oa +
                        nr**2*oa + res**2*ma*2)*batch*bw
            s_fp += (res**2*ma + nr**2*oa)*batch*bw
            in_c = out_c; res = nr
        ptr += 4
        if device == "gpu":
            eps = 1e-5
            feats.extend([float(depth_i), s_pw, s_dw, s_bytes,
                          s_pw/(s_bytes+eps), s_dw/(s_bytes+eps)])
        else:
            feats.extend([float(depth_i), s_pw, s_dw, s_bytes,
                          s_fp/ac_eps])
        tot_pw += s_pw; tot_dw += s_dw; tot_bytes += s_bytes; tot_fp += s_fp
    feats.extend([tot_pw, tot_dw, tot_bytes])
    if device != "gpu":
        feats.append(tot_fp)
    return feats


# ============================================================
# [FIX-7] Ridge preprocessing: selective log on large-scale columns only
# ============================================================
def ridge_preprocess_fit(X_tr, scale_threshold=1e4):
    """
    Returns (X_tr_transformed, transform_fn, scaler)
    Only columns with max|value| > scale_threshold are log-transformed;
    small-integer features like batch/quota/depth keep their linear scale.
    """
    col_max = np.abs(X_tr).max(axis=0)
    log_cols = col_max > scale_threshold

    def transform(X):
        X_out = X.copy().astype(np.float64)
        X_out[:, log_cols] = np.log1p(np.abs(X_out[:, log_cols]))
        return X_out

    X_tr_transformed = transform(X_tr)
    scaler = StandardScaler().fit(X_tr_transformed)
    return scaler.transform(X_tr_transformed), transform, scaler, log_cols


def ridge_preprocess_apply(X, transform_fn, scaler):
    return scaler.transform(transform_fn(X))


# ============================================================
# Dimension verification
# ============================================================
def verify_dims():
    ks = [3]*20; e = [3]*20; d = [2,2,2,2,2]
    expected = {
        "gpu": {1:3, 2:22, 3:28, 4:38},
        "cpu": {1:3, 2:20, 3:27, 4:32},
    }
    fns = {1:extract_c1, 2:extract_c2, 3:extract_c3, 4:extract_c4}
    ok = True
    for dev in ["gpu","cpu"]:
        for ci in range(1,5):
            feat = fns[ci](ks, e, d, 1, 25, dev)
            exp  = expected[dev][ci]
            passed = len(feat)==exp
            if not passed: ok = False
            status = "OK" if passed else f"FAIL(got {len(feat)}, want {exp})"
            print(f"  [{dev}] C{ci}: dim={len(feat)} {status}")
    return ok


# ============================================================
# Shared utilities
# ============================================================
def build_ds(data, device, extractor):
    Xl, Yl, Gl, Ml = [], [], [], []
    for ai, sample in enumerate(data):
        ks, e, d = sample["ks"], sample["e"], sample["d"]
        for (batch, res), lat in sample["latency_grid"].items():
            if lat <= 0: continue
            Xl.append(extractor(ks, e, d, batch, res, device))
            Yl.append(lat); Gl.append(ai)
            Ml.append({'batch': batch, 'res': res, 'arch_idx': ai})
    return (np.array(Xl, dtype=np.float64),
            np.array(Yl, dtype=np.float64),
            np.array(Gl, dtype=np.int32),
            Ml)


def holdout(G, Y_log):
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    X_dummy = np.zeros(len(Y_log))
    tr, te = next(gss.split(X_dummy, X_dummy, G))
    assert len(set(G[tr])&set(G[te]))==0
    return tr, te


def mets(y_true, y_pred, meta=None):
    tau = stratified_kendall_tau(y_true, y_pred, meta) if meta else np.nan
    # Also keep flat tau for diagnostic
    flat_tau, _ = kendalltau(y_true, y_pred)
    return {"mape": mean_absolute_percentage_error(y_true, y_pred)*100,
            "rmse": float(np.sqrt(np.mean((y_pred-y_true)**2))),
            "r2":   r2_score(y_true, y_pred),
            "tau_strat": tau,
            "tau_flat":  flat_tau if not np.isnan(flat_tau) else 0.0}


# ============================================================
# Study 1 — Sample Efficiency
# [FIX-4] Max N now clipped to the actual train size, not 1500
# ============================================================
def study1(data, device, n_trees):
    print("\n" + "="*60)
    print(f"  Study 1: Sample Efficiency (fixed n_trees={n_trees})")
    print("="*60)
    X4, Y, G, M = build_ds(data, device, extract_c4)
    X1, _, _, _ = build_ds(data, device, extract_c1)
    Yl = np.log1p(Y)
    tr, te = holdout(G, Yl)
    meta_te = [M[i] for i in te]
    all_archs = list(np.unique(G[tr]))
    n_train_archs = len(all_archs)
    print(f"  Training pool: {n_train_archs} unique architectures")

    rng = np.random.default_rng(42)
    # [FIX-4] N list clipped to actual max train arch count
    all_N = [100, 200, 400, 700, 1000, 1200, 1500]
    N_list = [N for N in all_N if N <= n_train_archs]
    if n_train_archs > max(N_list):
        N_list.append(n_train_archs)
    print(f"  Evaluating N ∈ {N_list}")

    results = []
    for N in N_list:
        sub_archs = rng.choice(all_archs, size=N, replace=False)
        mask = np.isin(G[tr], sub_archs)
        sub = tr[mask]
        p = {**BASE_LGBM, "objective":"huber","alpha":1.2,"n_estimators":n_trees}
        mhw = lgb.LGBMRegressor(**p)
        mhw.fit(X4[sub], Yl[sub])
        mb = lgb.LGBMRegressor(**p)
        mb.fit(X1[sub], Yl[sub])
        yhw   = np.expm1(mhw.predict(X4[te]))
        ybase = np.expm1(mb.predict(X1[te]))
        ytrue = np.expm1(Yl[te])
        mhw_r = mets(ytrue, yhw, meta_te)
        mb_r  = mets(ytrue, ybase, meta_te)
        r = {"N":N,
             "hw_mape": mhw_r["mape"], "hw_tau_strat": mhw_r["tau_strat"],
             "base_mape":mb_r["mape"], "base_tau_strat":mb_r["tau_strat"],
             "delta_mape": mb_r["mape"] - mhw_r["mape"]}
        results.append(r)
        print(f"  N={N:5d}: HW {r['hw_mape']:.2f}%  τ_strat={r['hw_tau_strat']:.4f} | "
              f"Base {r['base_mape']:.2f}%  τ_strat={r['base_tau_strat']:.4f} | "
              f"ΔMAPE={r['delta_mape']:+.2f}%")

    # [FIX-4] Also report full-data (N=all) asymptote as a separate diagnostic point
    print("\n  [Full-data asymptote — trained on ALL training archs, no hold-out val]")
    p = {**BASE_LGBM, "objective":"huber","alpha":1.2,"n_estimators":n_trees}
    mhw = lgb.LGBMRegressor(**p); mhw.fit(X4[tr], Yl[tr])
    mb  = lgb.LGBMRegressor(**p); mb.fit(X1[tr], Yl[tr])
    ytrue = np.expm1(Yl[te])
    mhw_r = mets(ytrue, np.expm1(mhw.predict(X4[te])), meta_te)
    mb_r  = mets(ytrue, np.expm1(mb.predict(X1[te])), meta_te)
    print(f"  Full(N={n_train_archs}): HW {mhw_r['mape']:.2f}%  τ_strat={mhw_r['tau_strat']:.4f} | "
          f"Base {mb_r['mape']:.2f}%  τ_strat={mb_r['tau_strat']:.4f}")
    return results


# ============================================================
# Study 2 — Regression Backbone (all 4 models)
# [FIX-7] Ridge preprocessing fixed to only log-transform large-scale columns
# ============================================================
def study2(data, device, n_trees):
    print("\n" + "="*60)
    print("  Study 2: Regression Backbone Sensitivity (4 models)")
    print("="*60)
    X, Y, G, M = build_ds(data, device, extract_c4)
    Yl = np.log1p(Y)
    tr, te = holdout(G, Yl)
    meta_te = [M[i] for i in te]
    ytrue = np.expm1(Yl[te])

    # [FIX-7] Selective log preprocessing for Ridge
    _, transform_fn, scaler, log_cols = ridge_preprocess_fit(X[tr])
    Xtr_s = ridge_preprocess_apply(X[tr], transform_fn, scaler)
    Xte_s = ridge_preprocess_apply(X[te], transform_fn, scaler)
    print(f"  Ridge preprocessing: {log_cols.sum()}/{X.shape[1]} cols log-transformed")

    models = {
        "LGBM-Huber":   lgb.LGBMRegressor(**BASE_LGBM, objective="huber", alpha=1.2, n_estimators=n_trees),
        "LGBM-MSE":     lgb.LGBMRegressor(**BASE_LGBM, objective="mse",   n_estimators=n_trees),
        "RandomForest": RandomForestRegressor(n_estimators=500, random_state=2026, n_jobs=-1),
        "Ridge":        Ridge(alpha=1.0),
    }
    results = []
    for name, model in models.items():
        if name == "Ridge":
            model.fit(Xtr_s, Yl[tr])
            yp = np.expm1(model.predict(Xte_s))
        else:
            model.fit(X[tr], Yl[tr])
            yp = np.expm1(model.predict(X[te]))
        r = {"model": name, **mets(ytrue, yp, meta_te)}
        results.append(r)
        print(f"  {name:<14}: MAPE={r['mape']:6.2f}%  τ_strat={r['tau_strat']:.4f}  R²={r['r2']:.4f}")
    return results


# ============================================================
# Study 3 — Quota-Stratified Contribution
# ============================================================
def study3(data, device, n_trees):
    print("\n" + "="*60)
    print("  Study 3: Quota-Stratified Feature Contribution")
    print("  (unified model trained on all quotas; subsets evaluated only)")
    print("="*60)
    X4, Y, G, M = build_ds(data, device, extract_c4)
    X1, _, _, _ = build_ds(data, device, extract_c1)
    Yl = np.log1p(Y)
    tr, te = holdout(G, Yl)

    p = {**BASE_LGBM, "objective":"huber","alpha":1.2,"n_estimators":n_trees}
    mhw = lgb.LGBMRegressor(**p); mhw.fit(X4[tr], Yl[tr])
    mb  = lgb.LGBMRegressor(**p); mb.fit(X1[tr], Yl[tr])
    phw = mhw.predict(X4[te])
    pb  = mb.predict(X1[te])

    qarr = np.array([m['res'] for m in M])[te]
    meta_te = [M[i] for i in te]
    results = []
    for Q in sorted(set(qarr)):
        mask = (qarr == Q)
        yt = np.expm1(Yl[te][mask])
        yh = np.expm1(phw[mask]); yb = np.expm1(pb[mask])
        sub_meta = [meta_te[i] for i in np.where(mask)[0]]
        mhw_r = mets(yt, yh, sub_meta)
        mb_r  = mets(yt, yb, sub_meta)
        r = {"Q": int(Q),
             "hw_mape":  mhw_r["mape"], "hw_tau_strat":  mhw_r["tau_strat"],
             "base_mape":mb_r["mape"],  "base_tau_strat":mb_r["tau_strat"],
             "delta_mape": mb_r["mape"] - mhw_r["mape"],
             "delta_tau_strat": mhw_r["tau_strat"] - mb_r["tau_strat"]}
        results.append(r)
        print(f"  Q={Q:3d}%  ΔMAPE={r['delta_mape']:+.2f}pp  Δτ_strat={r['delta_tau_strat']:+.4f}")
    return results


# ============================================================
# Study 4 — Incremental Feature Attribution via Linear Probe
# [FIX-7] Ridge preprocessing fixed
# ============================================================
def study4(data, device, n_trees):
    print("\n" + "="*60)
    print("  Study 4: Incremental Feature Attribution (C1→C2→C3→C4)")
    print("  Ridge linear probe + LightGBM")
    print("="*60)
    cfgs = [("C1 FLOPs-only",     extract_c1),
            ("C2 +Stage raw",      extract_c2),
            ("C3 +Align+Traffic",  extract_c3),
            ("C4 Full HW-Aware",   extract_c4)]
    dsets = {n: build_ds(data, device, fn) for n,fn in cfgs}
    X4, Y4, G4, M4 = dsets["C4 Full HW-Aware"]
    tr, te = holdout(G4, np.log1p(Y4))
    meta_te = [M4[i] for i in te]
    results = []
    for cname, _ in cfgs:
        X, Y, G, _ = dsets[cname]
        Yl = np.log1p(Y)
        ytrue = np.expm1(Yl[te])

        # [FIX-7] Ridge with selective log preprocessing
        _, transform_fn, scaler, log_cols = ridge_preprocess_fit(X[tr])
        Xtr_s = ridge_preprocess_apply(X[tr], transform_fn, scaler)
        Xte_s = ridge_preprocess_apply(X[te], transform_fn, scaler)
        ridge = Ridge(alpha=1.0)
        ridge.fit(Xtr_s, Yl[tr])
        r_ridge = mets(ytrue, np.expm1(ridge.predict(Xte_s)), meta_te)

        m = lgb.LGBMRegressor(**BASE_LGBM, objective="huber", alpha=1.2, n_estimators=n_trees)
        m.fit(X[tr], Yl[tr])
        r_lgbm = mets(ytrue, np.expm1(m.predict(X[te])), meta_te)

        row = {"config":cname, "dim":X.shape[1],
               "log_cols": int(log_cols.sum()),
               "ridge_mape":r_ridge["mape"], "ridge_tau_strat":r_ridge["tau_strat"], "ridge_r2":r_ridge["r2"],
               "lgbm_mape": r_lgbm["mape"],  "lgbm_tau_strat": r_lgbm["tau_strat"],  "lgbm_r2": r_lgbm["r2"]}
        results.append(row)
        print(f"  {cname:<22}({X.shape[1]:2d}-dim, {log_cols.sum():2d}log): "
              f"Ridge MAPE={r_ridge['mape']:6.2f}% τ={r_ridge['tau_strat']:.4f} | "
              f"LGBM MAPE={r_lgbm['mape']:5.2f}% τ={r_lgbm['tau_strat']:.4f}")
    print("  Note: Ridge MAPE now uses selective log-transform (large-scale cols only)")
    return results


# ============================================================
# Main
# ============================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device",  required=True, choices=["gpu","amd","intel"])
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--n_trees", type=int, default=None)
    parser.add_argument("--out", default=None)
    args = parser.parse_args()
    device = "gpu" if args.device=="gpu" else "cpu"
    with open(args.dataset,"rb") as f: data = pickle.load(f)
    print(f"Device: {args.device.upper()} | Archs: {len(data)}")

    print("\nVerifying feature dimensions …")
    assert verify_dims(), "Dimension check failed."

    if args.n_trees:
        n_trees = args.n_trees
        print(f"Using supplied n_trees={n_trees}")
    else:
        print("Estimating n_trees via 5-Fold CV with inner val split …")
        X, Y, G, _ = build_ds(data, device, extract_c4)
        Yl = np.log1p(Y)
        mr = 4000 if args.device=="gpu" else 4500
        iters = []
        for fold, (tr, te) in enumerate(GroupKFold(5).split(X, Yl, G)):
            # [FIX-2] Inner val split
            inner_tr, inner_val = inner_val_split(tr, G,
                                                    val_frac=0.15,
                                                    random_state=2025+fold)
            m = lgb.LGBMRegressor(**BASE_LGBM, objective="huber", alpha=1.2,
                                   n_estimators=mr)
            m.fit(X[inner_tr], Yl[inner_tr],
                  eval_set=[(X[inner_val], Yl[inner_val])],
                  callbacks=[lgb.early_stopping(400, verbose=False)])
            iters.append(m.best_iteration_)
            print(f"  Fold {fold+1}: best_iter={m.best_iteration_}")
        n_trees = int(np.median(iters))
        print(f"Median n_trees={n_trees}")

    results = {"device": args.device.upper(), "n_trees": n_trees,
               "study1": study1(data, device, n_trees),
               "study2": study2(data, device, n_trees),
               "study3": study3(data, device, n_trees),
               "study4": study4(data, device, n_trees)}

    out = args.out or f"ablation_{args.device}.pkl"
    with open(out, "wb") as f: pickle.dump(results, f)
    print(f"\n[OK] Saved to {out}")


if __name__ == "__main__":
    main()