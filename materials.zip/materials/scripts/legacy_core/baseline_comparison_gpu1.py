"""
baseline_comparison_gpu.py  —  FIXED VERSION
Direct head-to-head comparison of predictors on RTX 3090 dataset.

Critical fixes:
  [FIX-2] Baselines no longer use test-set for early-stopping.
          train_nn_baseline is called WITHOUT val_data — an inner val is
          carved from train automatically.
  [FIX-1] Stratified τ is the per-cell mean (unchanged — per_cell_metrics
          already returned the correct value).
  [FIX-A] Added BRP-NAS-Pairwise variant (original BRP-NAS uses ranking loss).
  [FIX-B] Global placeholder dim removed when quota is excluded.

Protocols:
  A) Q=100% only (baselines' home turf)
  B) Full quota range with naive quota-concat extension
"""
import os, sys, argparse, pickle, warnings
import numpy as np
import pandas as pd
import torch
import lightgbm as lgb
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_absolute_percentage_error, r2_score
from scipy.stats import kendalltau

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from baseline_models1  import ChainGCN, HELPMLP, encode_node_features, encode_flat_features
from baseline_trainer1 import set_seed, train_nn_baseline, evaluate_nn, per_cell_metrics

warnings.filterwarnings("ignore")

STAGE_CONFIGS = [
    (16,  24,  2),
    (24,  40,  2),
    (40,  80,  2),
    (80, 112,  1),
    (112,160,  2),
]
SM_COUNT = 82
LGBM_PARAMS = dict(
    objective='huber', alpha=1.2, n_estimators=4000, learning_rate=0.005,
    num_leaves=63, min_child_samples=8, subsample=0.8, colsample_bytree=0.8,
    random_state=2026, verbose=-1,
)


def extract_flops_only_features(ks, e, d, batch, q):
    total, r, ptr = 0.0, 112, 0
    for s, di in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[s]
        for i in range(di):
            k, ev = ks[ptr+i], e[ptr+i]
            mid = int(in_c * ev)
            st  = stride if i == 0 else 1
            nr  = r // st
            total += (2*r*r*in_c*mid + 2*nr*nr*k*k*mid + 2*nr*nr*mid*out_c) * batch
            in_c, r = out_c, nr
        ptr += 4
    return [np.log1p(total), batch, q/100.0]


def extract_hw_aware_features(ks, e, d, batch, q, sm_count=SM_COUNT):
    active_sms = sm_count * q/100.0
    total_depth = sum(d)
    active_ks, ptr = [], 0
    for di in d:
        for i in range(di): active_ks.append(ks[ptr+i])
        ptr += 4
    large_k_cnt = sum(1 for k in active_ks if k > 3)
    feats = [batch, q/100.0, active_sms, total_depth, large_k_cnt]

    total_pw = total_dw = total_bytes = 0.0
    curr_res, ptr = 112, 0
    for s, di in enumerate(d):
        in_c, out_c, stage_stride = STAGE_CONFIGS[s]
        s_pw = s_dw = s_b = 0.0
        for i in range(di):
            k, ev = ks[ptr+i], e[ptr+i]
            mid   = int(in_c * ev)
            mid_a = ((mid + 15)//16)*16
            in_a  = ((in_c + 15)//16)*16
            out_a = ((out_c + 15)//16)*16
            st    = stage_stride if i == 0 else 1
            nr    = curr_res // st
            mac_exp = curr_res*curr_res * in_a  * mid_a
            mac_dw  = nr*nr * k*k * mid_a
            mac_proj= nr*nr * mid_a * out_a
            s_pw += (mac_exp + mac_proj)*2.0*batch
            s_dw +=  mac_dw*2.0*batch
            s_b  += (curr_res*curr_res*in_a
                     + in_a*mid_a + k*k*mid_a + mid_a*out_a
                     + nr*nr*out_a
                     + curr_res*curr_res*mid_a*2) * batch * 2.0
            in_c, curr_res = out_c, nr
        ptr += 4
        feats.extend([di, s_pw, s_dw, s_b,
                      s_pw/(s_b+1e-5), s_dw/(s_b+1e-5)])
        total_pw += s_pw; total_dw += s_dw; total_bytes += s_b
    feats.extend([total_pw, total_dw, total_bytes])
    return feats


def prepare_dataset(path, quota_filter=None):
    with open(path, "rb") as f:
        data = pickle.load(f)
    rows = []
    for arch_idx, s in enumerate(data):
        for (b, q), lat in s["latency_grid"].items():
            if lat <= 0: continue
            if quota_filter is not None and q not in quota_filter: continue
            rows.append({
                "arch_idx": arch_idx,
                "ks": s["ks"], "e": s["e"], "d": s["d"],
                "batch": b, "quota": q, "latency": lat,
            })
    return data, rows


def build_tensors(rows, include_quota_in_global):
    """
    [FIX-B] When quota is NOT in global, global_g has only 1 dim (batch).
    """
    node_X, node_m, flat_X, global_g = [], [], [], []
    flops_X, hw_X, y, meta = [], [], [], []

    for r in rows:
        nX, nm = encode_node_features(r["ks"], r["e"], r["d"], STAGE_CONFIGS)
        node_X.append(nX); node_m.append(nm)
        flat_X.append(encode_flat_features(r["ks"], r["e"], r["d"]))

        g = [r["batch"] / 32.0]
        if include_quota_in_global:
            g.append(r["quota"] / 100.0)
        # [FIX-B] If not including quota, g stays 1-dim — no dummy placeholder.
        global_g.append(g)

        flops_X.append(extract_flops_only_features(r["ks"], r["e"], r["d"],
                                                   r["batch"], r["quota"]))
        hw_X.append(extract_hw_aware_features(r["ks"], r["e"], r["d"],
                                              r["batch"], r["quota"]))
        y.append(r["latency"])
        meta.append({"batch": r["batch"], "res": r["quota"], "arch_idx": r["arch_idx"]})

    tensors = {
        "node_X":   torch.tensor(node_X,   dtype=torch.float32),
        "node_m":   torch.tensor(node_m,   dtype=torch.float32),
        "flat_X":   torch.tensor(flat_X,   dtype=torch.float32),
        "global_g": torch.tensor(global_g, dtype=torch.float32),
        "flops_X":  np.array(flops_X, dtype=np.float64),
        "hw_X":     np.array(hw_X,    dtype=np.float64),
        "y":        np.array(y,       dtype=np.float64),
        "y_log":    torch.tensor(np.log1p(y), dtype=torch.float32),
        "groups":   np.array([r["arch_idx"] for r in rows], dtype=np.int32),
        "meta":     meta,
    }
    return tensors


def run_all_baselines(T, tr_idx, te_idx, protocol_label):
    """
    [FIX-2] Baselines trained with inner val split (no test-set leakage).
    [FIX-A] BRP-NAS evaluated with both Huber regression loss and pairwise
            ranking loss (the latter matches original BRP-NAS).
    """
    results = {}
    print(f"\n══════════════════════════════════════════════════════════════")
    print(f"  Running Protocol: {protocol_label}")
    print(f"  train samples = {len(tr_idx)}   test samples = {len(te_idx)}")
    print(f"  unique train archs = {len(np.unique(T['groups'][tr_idx]))}  "
          f"test archs = {len(np.unique(T['groups'][te_idx]))}")
    print(f"══════════════════════════════════════════════════════════════")

    tr_set, te_set = set(T["groups"][tr_idx]), set(T["groups"][te_idx])
    assert tr_set.isdisjoint(te_set), "Architecture leakage between train & test!"

    y_true_te_raw = T["y"][te_idx]
    global_in_dim = T["global_g"].shape[1]

    # ---- A1. BRP-NAS (Huber regression) ------------------------------------
    print("\n▶ [A1] BRP-NAS ChainGCN (Huber)")
    set_seed(2026)
    gcn = ChainGCN(global_in=global_in_dim)
    gcn = train_nn_baseline(
        gcn,
        train_data=(T["node_X"][tr_idx], T["node_m"][tr_idx],
                    T["global_g"][tr_idx], T["y_log"][tr_idx]),
        val_data=None,     # [FIX-2] no test as val!
        tag="BRP-NAS-Huber", loss_type="huber",
    )
    yt, yp = evaluate_nn(gcn, (T["node_X"][te_idx], T["node_m"][te_idx],
                               T["global_g"][te_idx], T["y_log"][te_idx]))
    results["BRP-NAS-Huber"] = (yt, yp)

    # ---- A2. BRP-NAS (Pairwise Ranking — original BRP-NAS) -----------------
    print("\n▶ [A2] BRP-NAS ChainGCN (Pairwise Rank — original)")
    set_seed(2026)
    gcn_pw = ChainGCN(global_in=global_in_dim)
    gcn_pw = train_nn_baseline(
        gcn_pw,
        train_data=(T["node_X"][tr_idx], T["node_m"][tr_idx],
                    T["global_g"][tr_idx], T["y_log"][tr_idx]),
        val_data=None,
        tag="BRP-NAS-Pair", loss_type="pairwise",
        batch_size=256,  # pairwise loss benefits from larger effective batch
    )
    yt, yp = evaluate_nn(gcn_pw, (T["node_X"][te_idx], T["node_m"][te_idx],
                                  T["global_g"][te_idx], T["y_log"][te_idx]))
    results["BRP-NAS-Pairwise"] = (yt, yp)

    # ---- B. HELP MLP -------------------------------------------------------
    print("\n▶ [B] HELP-MLP")
    set_seed(2026)
    mlp = HELPMLP(global_in=global_in_dim)
    mlp = train_nn_baseline(
        mlp,
        train_data=(T["flat_X"][tr_idx], T["global_g"][tr_idx], T["y_log"][tr_idx]),
        val_data=None,     # [FIX-2]
        tag="HELP-MLP", loss_type="huber",
    )
    yt, yp = evaluate_nn(mlp, (T["flat_X"][te_idx], T["global_g"][te_idx],
                               T["y_log"][te_idx]))
    results["HELP-MLP"] = (yt, yp)

    # ---- C. FLOPs-only LightGBM (with inner val split) ---------------------
    # [FIX-2] Inner val for LGBM too
    g_tr = T["groups"][tr_idx]
    gss_inner = GroupShuffleSplit(n_splits=1, test_size=0.15, random_state=2025)
    dummy = np.zeros(len(tr_idx))
    inner_tr_rel, inner_val_rel = next(gss_inner.split(dummy, dummy, g_tr))
    inner_tr, inner_val = tr_idx[inner_tr_rel], tr_idx[inner_val_rel]

    print("\n▶ [C] FLOPs-only LightGBM")
    m = lgb.LGBMRegressor(**LGBM_PARAMS)
    m.fit(T["flops_X"][inner_tr], T["y_log"].numpy()[inner_tr],
          eval_set=[(T["flops_X"][inner_val], T["y_log"].numpy()[inner_val])],
          callbacks=[lgb.early_stopping(400, verbose=False)])
    yp = np.expm1(m.predict(T["flops_X"][te_idx]))
    results["FLOPs-only"] = (y_true_te_raw, yp)

    # ---- D. HW-Aware LightGBM (ours) ---------------------------------------
    print("\n▶ [D] HW-Aware LightGBM (ours)")
    m = lgb.LGBMRegressor(**LGBM_PARAMS)
    m.fit(T["hw_X"][inner_tr], T["y_log"].numpy()[inner_tr],
          eval_set=[(T["hw_X"][inner_val], T["y_log"].numpy()[inner_val])],
          callbacks=[lgb.early_stopping(400, verbose=False)])
    yp = np.expm1(m.predict(T["hw_X"][te_idx]))
    results["HW-Aware (ours)"] = (y_true_te_raw, yp)

    return results


def summarise_results(results, meta_test, cells, protocol_label, out_dir):
    rows = []
    print(f"\n┌─────────────────────────────────────────────────────────────")
    print(f"│ Summary — {protocol_label}")
    print(f"├─────────────────────────────────────────────────────────────")
    print(f"│ {'Predictor':<22} {'MAPE %':>10} {'R²':>8} {'τ_strat':>10}")
    print(f"├─────────────────────────────────────────────────────────────")
    for name, (yt, yp) in results.items():
        per_cell, ov_mape, ov_r2, mean_tau = per_cell_metrics(yt, yp, meta_test, cells)
        rows.append({"protocol": protocol_label, "predictor": name,
                     "MAPE%": ov_mape, "R2": ov_r2, "tau_strat": mean_tau})
        print(f"│ {name:<22} {ov_mape:>10.2f} {ov_r2:>8.4f} {mean_tau:>10.4f}")
    print(f"└─────────────────────────────────────────────────────────────")
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="dataset_gpu_hybrid.pkl")
    ap.add_argument("--out",  default="baseline_results_gpu")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    print(f"🚀 Loading {args.data} ...")
    print(f"   device = {'CUDA' if torch.cuda.is_available() else 'CPU'}")
    all_rows_all = []

    # --------- Protocol A — Q=100% head-to-head ---------
    _, rows_A = prepare_dataset(args.data, quota_filter={100})
    T_A = build_tensors(rows_A, include_quota_in_global=False)
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    tr_A, te_A = next(gss.split(T_A["flops_X"], T_A["y"], T_A["groups"]))
    meta_te_A  = [T_A["meta"][i] for i in te_A]
    cells_A    = [(b, 100) for b in [1, 8, 16, 32]]
    res_A = run_all_baselines(T_A, tr_A, te_A, "Protocol A (Q=100% only)")
    all_rows_all.extend(summarise_results(res_A, meta_te_A, cells_A,
                                          "Protocol A (Q=100%)", args.out))

    # --------- Protocol B — Full quota range ---------
    _, rows_B = prepare_dataset(args.data, quota_filter=None)
    T_B = build_tensors(rows_B, include_quota_in_global=True)
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    tr_B, te_B = next(gss.split(T_B["flops_X"], T_B["y"], T_B["groups"]))
    meta_te_B  = [T_B["meta"][i] for i in te_B]
    cells_B    = [(b, q) for b in [1, 8, 16, 32] for q in [10, 25, 50, 100]]
    res_B = run_all_baselines(T_B, tr_B, te_B, "Protocol B (full quota, naive-concat)")
    all_rows_all.extend(summarise_results(res_B, meta_te_B, cells_B,
                                          "Protocol B (full quota)", args.out))

    df = pd.DataFrame(all_rows_all)
    csv_path = os.path.join(args.out, "gpu_baseline_summary.csv")
    df.to_csv(csv_path, index=False)
    print(f"\n✅ Results saved → {csv_path}")

    full_rows = []
    for label, res, meta_te, cells in [
        ("Protocol A", res_A, meta_te_A, cells_A),
        ("Protocol B", res_B, meta_te_B, cells_B),
    ]:
        for name, (yt, yp) in res.items():
            per_cell, _, _, _ = per_cell_metrics(yt, yp, meta_te, cells)
            for (b, q), (mape, tau) in per_cell.items():
                full_rows.append({"protocol": label, "predictor": name,
                                  "batch": b, "quota": q,
                                  "MAPE%": mape, "tau": tau})
    pd.DataFrame(full_rows).to_csv(
        os.path.join(args.out, "gpu_baseline_percell.csv"), index=False)
    print(f"✅ Per-cell breakdown → {os.path.join(args.out, 'gpu_baseline_percell.csv')}")
    print("\n🎉 GPU baseline comparison complete.")


if __name__ == "__main__":
    main()