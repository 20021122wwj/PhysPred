"""
cpu_train_eval.py  —  FIXED VERSION
Hardware-Aware CPU Latency Predictor

Critical fixes over the previous version:
  [FIX-1] τ_strat now correctly computed as per-cell mean (matches paper §III.D)
  [FIX-2] Inner validation split eliminates test-set leakage in early-stopping
  [FIX-3] Report ± std across 5 folds for all metrics
  [FIX-4] No longer reports flat-τ as "stratified τ"
"""
import os
import pickle
import numpy as np
import pandas as pd
import lightgbm as lgb
from collections import defaultdict
from sklearn.model_selection import GroupKFold, GroupShuffleSplit
from sklearn.metrics import mean_absolute_percentage_error, r2_score
from scipy.stats import kendalltau
import joblib
import warnings

warnings.filterwarnings("ignore")

# ============================================================
# Configuration
# ============================================================
DATASET_FILE    = "dataset_cpu_intel.pkl"
MODEL_SAVE_PATH = "cpu_predictor_intel.pkl"
N_CV_FOLDS      = 5

STAGE_CONFIGS = [
    (16,  24,  2),
    (24,  40,  2),
    (40,  80,  2),
    (80,  112, 1),
    (112, 160, 2),
]


# ============================================================
# [FIX-1] Stratified τ: per-cell mean
# ============================================================
def stratified_kendall_tau(y_true, y_pred, meta, return_per_cell=False):
    grid = defaultdict(lambda: {'t': [], 'p': []})
    for i, m in enumerate(meta):
        grid[(m['batch'], m['res'])]['t'].append(y_true[i])
        grid[(m['batch'], m['res'])]['p'].append(y_pred[i])

    per_cell = {}
    taus = []
    for key, v in grid.items():
        if len(v['t']) < 2:
            per_cell[key] = np.nan
            continue
        tau, _ = kendalltau(v['t'], v['p'])
        if not np.isnan(tau):
            taus.append(tau)
            per_cell[key] = tau
        else:
            per_cell[key] = np.nan

    mean_tau = float(np.mean(taus)) if taus else np.nan
    if return_per_cell:
        return mean_tau, per_cell
    return mean_tau


def inner_validation_split(tr_idx, groups, val_frac=0.15, random_state=2025):
    gss = GroupShuffleSplit(n_splits=1, test_size=val_frac,
                             random_state=random_state)
    X_dummy = np.zeros(len(tr_idx))
    g_tr    = groups[tr_idx]
    inner_tr, inner_val = next(gss.split(X_dummy, X_dummy, g_tr))
    return tr_idx[inner_tr], tr_idx[inner_val]


# ============================================================
# Feature Extraction — Hardware-Aware CPU (main model)
# ============================================================
def extract_cpu_hardware_features(ks, e, d, batch, resource_percent):
    """
    Per-(arch, batch, quota) feature vector for CPU latency prediction.
    AVX2 FP32 alignment = 8 elements; FP32 = 4 bytes.
    """
    active_cores = 4.0 * (resource_percent / 100.0)

    total_depth = sum(d)
    features = [batch, active_cores, total_depth]

    total_pw, total_dw, total_bytes, total_act_footprint = 0.0, 0.0, 0.0, 0.0
    curr_res, ptr = 112, 0

    for stage_idx, depth_i in enumerate(d):
        in_c, out_c, stage_stride = STAGE_CONFIGS[stage_idx]
        s_pw, s_dw, s_bytes, s_footprint = 0.0, 0.0, 0.0, 0.0

        for i in range(depth_i):
            k_val, e_val = ks[ptr + i], e[ptr + i]
            mid_c        = int(in_c * e_val)

            mid_a = ((mid_c + 7) // 8) * 8
            in_a  = ((in_c  + 7) // 8) * 8
            out_a = ((out_c + 7) // 8) * 8

            this_stride = stage_stride if i == 0 else 1
            next_res    = curr_res // this_stride

            mac_exp  = curr_res ** 2 * in_a  * mid_a
            mac_dw   = next_res ** 2 * k_val ** 2 * mid_a
            mac_proj = next_res ** 2 * mid_a * out_a

            s_pw += (mac_exp + mac_proj) * 2.0 * batch
            s_dw +=  mac_dw              * 2.0 * batch

            s_bytes += (
                curr_res ** 2 * in_a  +
                in_a * mid_a + k_val ** 2 * mid_a + mid_a * out_a +
                next_res ** 2 * out_a +
                curr_res ** 2 * mid_a * 2
            ) * batch * 4.0

            s_footprint += (curr_res ** 2 * mid_a + next_res ** 2 * out_a) * batch * 4.0

            in_c     = out_c
            curr_res = next_res
        ptr += 4

        footprint_per_core = s_footprint / (active_cores + 1e-5)

        features.extend([
            depth_i,
            s_pw, s_dw, s_bytes,
            footprint_per_core,
        ])
        total_pw            += s_pw
        total_dw            += s_dw
        total_bytes         += s_bytes
        total_act_footprint += s_footprint

    features.extend([total_pw, total_dw, total_bytes, total_act_footprint])
    return features


def get_cpu_feature_names():
    names = ["batch", "active_cores", "total_depth"]
    for i in range(5):
        names += [
            f"s{i}_depth", f"s{i}_pw_flops", f"s{i}_dw_flops",
            f"s{i}_bytes",  f"s{i}_footprint_per_core",
        ]
    names += ["total_pw_flops", "total_dw_flops", "total_bytes", "total_act_footprint"]
    return names  # 32 features total


def extract_flops_only_features(ks, e, d, batch, resource_percent):
    active_cores = 4.0 * (resource_percent / 100.0)
    total_flops, curr_res, ptr = 0.0, 112, 0
    for stage_idx, depth_i in enumerate(d):
        in_c, out_c, stride = STAGE_CONFIGS[stage_idx]
        for i in range(depth_i):
            k_val, e_val = ks[ptr + i], e[ptr + i]
            mid_c        = int(in_c * e_val)
            this_stride  = stride if i == 0 else 1
            next_res     = curr_res // this_stride
            total_flops += (
                2 * curr_res ** 2 * in_c  * mid_c +
                2 * next_res ** 2 * k_val ** 2 * mid_c +
                2 * next_res ** 2 * mid_c * out_c
            ) * batch
            in_c     = out_c
            curr_res = next_res
        ptr += 4
    return [np.log1p(total_flops), batch, active_cores]


# ============================================================
# Load Dataset
# ============================================================
print("🚀 [CPU] Building Hardware-Aware Latency Predictor (Fixed Version)...")

with open(DATASET_FILE, "rb") as f:
    data = pickle.load(f)

X_hw_list, X_base_list = [], []
Y_list, groups_list, meta_list = [], [], []

for arch_idx, sample in enumerate(data):
    ks, e, d = sample['ks'], sample['e'], sample['d']
    for (batch, res), latency in sample['latency_grid'].items():
        if latency <= 0:
            continue
        X_hw_list.append(extract_cpu_hardware_features(ks, e, d, batch, res))
        X_base_list.append(extract_flops_only_features(ks, e, d, batch, res))
        Y_list.append(latency)
        groups_list.append(arch_idx)
        meta_list.append({'batch': batch, 'res': res, 'arch_idx': arch_idx})

X_hw   = np.array(X_hw_list,   dtype=np.float64)
X_base = np.array(X_base_list, dtype=np.float64)
Y      = np.array(Y_list,      dtype=np.float64)
groups = np.array(groups_list, dtype=np.int32)
Y_log  = np.log1p(Y)

print(f"  Dataset : {len(data)} architectures, {len(Y)} (arch × config) pairs")
print(f"  Features: {X_hw.shape[1]} (HW-Aware)  |  {X_base.shape[1]} (FLOPs-only baseline)")

# ============================================================
# LightGBM Hyperparameters
# ============================================================
LGBM_PARAMS = dict(
    objective        = 'huber',
    alpha            = 1.2,
    n_estimators     = 4500,
    learning_rate    = 0.005,
    num_leaves       = 63,
    min_child_samples = 8,
    subsample        = 0.8,
    colsample_bytree = 0.8,
    random_state     = 2026,
    verbose          = -1,
)

# ============================================================
# 5-Fold GroupKFold CV with proper inner val split
# ============================================================
print(f"\n{'='*70}")
print(f"  5-Fold GroupKFold CV  (OOD architecture split + inner val split)")
print(f"  Total unique architectures: {len(np.unique(groups))}")
print(f"{'='*70}")

gkf = GroupKFold(n_splits=N_CV_FOLDS)

cv_mape_hw,   cv_tau_hw   = [], []
cv_mape_base, cv_tau_base = [], []
cv_r2_hw,     cv_rmse_hw  = [], []
best_iters_hw, best_iters_base = [], []

for fold, (tr_idx, te_idx) in enumerate(gkf.split(X_hw, Y_log, groups)):
    assert len(set(groups[tr_idx]) & set(groups[te_idx])) == 0, \
        f"Fold {fold}: architecture leakage!"

    inner_tr, inner_val = inner_validation_split(tr_idx, groups,
                                                  val_frac=0.15,
                                                  random_state=2025 + fold)
    assert len(set(groups[inner_tr]) & set(groups[inner_val])) == 0
    assert len(set(groups[inner_val]) & set(groups[te_idx])) == 0

    y_true = np.expm1(Y_log[te_idx])
    meta_te_fold = [meta_list[i] for i in te_idx]

    m = lgb.LGBMRegressor(**LGBM_PARAMS)
    m.fit(X_hw[inner_tr], Y_log[inner_tr],
          eval_set=[(X_hw[inner_val], Y_log[inner_val])],
          callbacks=[lgb.early_stopping(400, verbose=False)])
    best_iters_hw.append(m.best_iteration_)
    y_pred   = np.expm1(m.predict(X_hw[te_idx]))
    mape_hw  = mean_absolute_percentage_error(y_true, y_pred) * 100
    tau_hw   = stratified_kendall_tau(y_true, y_pred, meta_te_fold)
    r2_hw    = r2_score(y_true, y_pred)
    rmse_hw  = float(np.sqrt(np.mean((y_pred - y_true) ** 2)))
    cv_mape_hw.append(mape_hw); cv_tau_hw.append(tau_hw)
    cv_r2_hw.append(r2_hw);     cv_rmse_hw.append(rmse_hw)

    mb = lgb.LGBMRegressor(**LGBM_PARAMS)
    mb.fit(X_base[inner_tr], Y_log[inner_tr],
           eval_set=[(X_base[inner_val], Y_log[inner_val])],
           callbacks=[lgb.early_stopping(400, verbose=False)])
    best_iters_base.append(mb.best_iteration_)
    y_pred_b = np.expm1(mb.predict(X_base[te_idx]))
    mape_b   = mean_absolute_percentage_error(y_true, y_pred_b) * 100
    tau_b    = stratified_kendall_tau(y_true, y_pred_b, meta_te_fold)
    cv_mape_base.append(mape_b); cv_tau_base.append(tau_b)

    print(f"  Fold {fold+1}:  "
          f"HW  MAPE={mape_hw:5.2f}%  τ_strat={tau_hw:.4f}  |  "
          f"FLOPs  MAPE={mape_b:5.2f}%  τ_strat={tau_b:.4f}  |  "
          f"best_iter={m.best_iteration_}")

print()
print(f"  [HW-Aware]   CV MAPE    = {np.mean(cv_mape_hw):.2f}% ± {np.std(cv_mape_hw):.2f}%")
print(f"  [HW-Aware]   CV τ_strat = {np.mean(cv_tau_hw):.4f} ± {np.std(cv_tau_hw):.4f}")
print(f"  [HW-Aware]   CV R²      = {np.mean(cv_r2_hw):.4f} ± {np.std(cv_r2_hw):.4f}")
print(f"  [HW-Aware]   CV RMSE    = {np.mean(cv_rmse_hw):.3f} ± {np.std(cv_rmse_hw):.3f} ms")
print(f"  [FLOPs-only] CV MAPE    = {np.mean(cv_mape_base):.2f}% ± {np.std(cv_mape_base):.2f}%")
print(f"  [FLOPs-only] CV τ_strat = {np.mean(cv_tau_base):.4f} ± {np.std(cv_tau_base):.4f}")
print(f"  [Δ Ablation] ΔMAPE={np.mean(cv_mape_base)-np.mean(cv_mape_hw):+.2f}pp  "
      f"Δτ_strat={np.mean(cv_tau_hw)-np.mean(cv_tau_base):+.4f}")

# ============================================================
# Final Model — 80/20 hold-out
# ============================================================
gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
tr_idx, te_idx = next(gss.split(X_hw, Y_log, groups))
assert len(set(groups[tr_idx]) & set(groups[te_idx])) == 0

final_n_iters = int(np.median(best_iters_hw))
final_params  = {**LGBM_PARAMS, 'n_estimators': final_n_iters}

final_model = lgb.LGBMRegressor(**final_params)
final_model.fit(X_hw[tr_idx], Y_log[tr_idx])

y_pred    = np.expm1(final_model.predict(X_hw[te_idx]))
y_true    = np.expm1(Y_log[te_idx])
meta_test = [meta_list[i] for i in te_idx]

overall_mape  = mean_absolute_percentage_error(y_true, y_pred) * 100
overall_r2    = r2_score(y_true, y_pred)
overall_rmse  = float(np.sqrt(np.mean((y_pred - y_true) ** 2)))
overall_nrmse = overall_rmse / np.mean(y_true) * 100
overall_tau, per_cell_tau = stratified_kendall_tau(y_true, y_pred,
                                                    meta_test,
                                                    return_per_cell=True)

# ============================================================
# Paper Tables
# ============================================================
print(f"\n{'='*70}")
print(f"🏆 Table I: HW-Aware CPU Model — Hold-out Test Performance")
print(f"   ➤ Unseen architectures (OOD)  : {len(np.unique(groups[te_idx]))}")
print(f"   ➤ Hold-out MAPE               : {overall_mape:.2f}%")
print(f"   ➤ Hold-out RMSE               : {overall_rmse:.3f} ms")
print(f"   ➤ Hold-out nRMSE              : {overall_nrmse:.2f}%")
print(f"   ➤ Hold-out R²                 : {overall_r2:.4f}")
print(f"   ➤ Hold-out τ_strat (per-cell) : {overall_tau:.4f}")
print(f"   ➤ 5-Fold CV MAPE              : {np.mean(cv_mape_hw):.2f}% ± {np.std(cv_mape_hw):.2f}%")
print(f"   ➤ 5-Fold CV τ_strat           : {np.mean(cv_tau_hw):.4f} ± {np.std(cv_tau_hw):.4f}")
print(f"   ➤ Final model n_estimators    : {final_n_iters}")
print("-" * 70)

grid = {}
for i, m in enumerate(meta_test):
    k = (m['batch'], m['res'])
    grid.setdefault(k, {'true': [], 'pred': []})
    grid[k]['true'].append(y_true[i])
    grid[k]['pred'].append(y_pred[i])

batches = [1, 8, 16, 32]
quotas  = [25, 50, 100]

print("📈 Table III: Per-Cell MAPE (%) and Kendall's τ")
print(f"{'Batch':>6} | {'Quota':>6} | {'MAPE%':>7} | {'τ_cell':>7} | {'N':>4}")
print("-" * 50)
for b in batches:
    for q in quotas:
        if (b, q) in grid:
            t = np.array(grid[(b, q)]['true'])
            p = np.array(grid[(b, q)]['pred'])
            mape_c = mean_absolute_percentage_error(t, p) * 100
            tau_c, _ = kendalltau(t, p) if len(t) > 1 else (np.nan, None)
            tau_c = tau_c if not np.isnan(tau_c) else 0.0
            print(f"{b:>6} | {q:>5}% | {mape_c:>6.2f}% | {tau_c:>7.4f} | {len(t):>4}")

print(f"\n   🚀 Stratified Kendall's τ (per-cell mean) : {overall_tau:.4f}")
print("=" * 70)

# Feature importance
feat_names = get_cpu_feature_names()
fi_df = pd.DataFrame({
    'feature':    feat_names,
    'importance': final_model.feature_importances_,
}).sort_values('importance', ascending=False).reset_index(drop=True)

print("\n📊 Top-15 Feature Importances (by LightGBM split gain):")
print(fi_df.head(15).to_string(index=False))

joblib.dump(final_model, MODEL_SAVE_PATH)
fi_csv = MODEL_SAVE_PATH.replace('.pkl', '_feature_importance.csv')
fi_df.to_csv(fi_csv, index=False)

per_cell_rows = []
for (b, q), d_ in grid.items():
    t = np.array(d_['true']); p = np.array(d_['pred'])
    mape_c = mean_absolute_percentage_error(t, p) * 100
    tau_c, _ = kendalltau(t, p) if len(t) > 1 else (np.nan, None)
    per_cell_rows.append({'batch': b, 'quota': q, 'n': len(t),
                          'MAPE%': mape_c,
                          'tau': tau_c if not np.isnan(tau_c) else 0.0})
pd.DataFrame(per_cell_rows).to_csv(
    MODEL_SAVE_PATH.replace('.pkl', '_per_cell.csv'), index=False)

cv_summary = pd.DataFrame({
    'metric': ['MAPE', 'tau_strat', 'R2', 'RMSE'],
    'mean':   [np.mean(cv_mape_hw), np.mean(cv_tau_hw),
               np.mean(cv_r2_hw),   np.mean(cv_rmse_hw)],
    'std':    [np.std(cv_mape_hw),  np.std(cv_tau_hw),
               np.std(cv_r2_hw),    np.std(cv_rmse_hw)],
})
cv_summary.to_csv(MODEL_SAVE_PATH.replace('.pkl', '_cv_summary.csv'), index=False)

print(f"\n✅ Model saved            → {MODEL_SAVE_PATH}")
print(f"✅ Feature importance CSV → {fi_csv}")
print(f"✅ Per-cell results CSV   → {MODEL_SAVE_PATH.replace('.pkl', '_per_cell.csv')}")
print(f"✅ CV summary CSV         → {MODEL_SAVE_PATH.replace('.pkl', '_cv_summary.csv')}")