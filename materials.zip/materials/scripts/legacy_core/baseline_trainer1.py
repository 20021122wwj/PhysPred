"""
baseline_trainer.py  —  FIXED VERSION

Critical fixes:
  [FIX-2] Proper inner validation split — no more test-set leakage in early-stop.
          If val_data is None, train_nn_baseline splits an inner val from train.
  [FIX-1] per_cell_metrics uses per-cell tau (unchanged — was already correct)
          but returns NaN properly instead of filling with 0.
  [FIX-A] Supports pairwise ranking loss for BRP-NAS reproduction.
"""
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import mean_absolute_percentage_error, r2_score
from scipy.stats import kendalltau

from baseline_models1 import pairwise_ranking_loss


def set_seed(seed=2026):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _inner_val_split(train_tensors, val_frac=0.15, seed=2025):
    """
    [FIX-2] Split train tensors into (inner_train, inner_val) at sample level.
    NOTE: For strict arch-level splitting, callers should pre-split at the arch
    level before calling this trainer. This sample-level split is acceptable
    when caller has already done arch-level hold-out.
    """
    n = train_tensors[-1].shape[0]
    g = torch.Generator().manual_seed(seed)
    perm = torch.randperm(n, generator=g)
    n_val = max(1, int(n * val_frac))
    val_idx, tr_idx = perm[:n_val], perm[n_val:]
    tr_tensors  = tuple(t[tr_idx]  for t in train_tensors)
    val_tensors = tuple(t[val_idx] for t in train_tensors)
    return tr_tensors, val_tensors


def train_nn_baseline(model, train_data, val_data=None, *,
                      lr=1e-3, weight_decay=1e-5, epochs=200,
                      batch_size=512, patience=20, verbose=True, tag="",
                      loss_type="huber", huber_delta=1.0, val_frac=0.15,
                      seed=2025):
    """
    [FIX-2] If val_data is None, automatically carve a val split from train.
            This is the RECOMMENDED usage — callers should NOT pass test as val.
    [FIX-A] loss_type: "huber" (default), "mse", or "pairwise" (BRP-NAS original)
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model  = model.to(device)

    # [FIX-2] If caller did not supply val, derive one from train.
    if val_data is None:
        train_data, val_data = _inner_val_split(train_data,
                                                 val_frac=val_frac, seed=seed)
        if verbose:
            print(f"    [{tag}] inner val split: "
                  f"tr={train_data[-1].shape[0]}  val={val_data[-1].shape[0]}")

    train_tensors = [t.to(device) for t in train_data]
    val_tensors   = [t.to(device) for t in val_data]

    train_ds = TensorDataset(*train_tensors)
    loader   = DataLoader(train_ds, batch_size=batch_size, shuffle=True)

    opt   = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)

    best_val_mape = float("inf")
    best_state    = {k: v.clone() for k, v in model.state_dict().items()}
    waited        = 0

    for ep in range(epochs):
        model.train()
        for batch in loader:
            *inputs, y = batch
            pred = model(*inputs)
            if loss_type == "huber":
                loss = F.huber_loss(pred, y, delta=huber_delta)
            elif loss_type == "mse":
                loss = F.mse_loss(pred, y)
            elif loss_type == "pairwise":
                loss = pairwise_ranking_loss(pred, y)
            else:
                raise ValueError(f"unknown loss_type {loss_type}")
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
        sched.step()

        model.eval()
        with torch.no_grad():
            *vinputs, vy = val_tensors
            vpred        = model(*vinputs).cpu().numpy()
        vy_np    = vy.cpu().numpy()
        val_mape = mean_absolute_percentage_error(
            np.expm1(vy_np), np.expm1(vpred)) * 100

        if val_mape < best_val_mape - 1e-3:
            best_val_mape = val_mape
            best_state    = {k: v.clone() for k, v in model.state_dict().items()}
            waited        = 0
        else:
            waited += 1
            if waited >= patience:
                if verbose:
                    print(f"    [{tag}] early-stop at epoch {ep+1}  "
                          f"best val MAPE = {best_val_mape:.2f}%")
                break

        if verbose and (ep + 1) % 20 == 0:
            print(f"    [{tag}] ep {ep+1:3d}  val MAPE = {val_mape:.2f}%  "
                  f"(best {best_val_mape:.2f}%)")

    model.load_state_dict(best_state)
    return model


def evaluate_nn(model, eval_data):
    device = next(model.parameters()).device
    model.eval()
    with torch.no_grad():
        inputs_dev = [t.to(device) for t in eval_data[:-1]]
        pred_log   = model(*inputs_dev).cpu().numpy()
    y_log = eval_data[-1].cpu().numpy()
    return np.expm1(y_log), np.expm1(pred_log)


def per_cell_metrics(y_true, y_pred, meta, cells):
    """
    Return (per_cell_dict, overall_mape, overall_r2, mean_per_cell_tau).
    mean_per_cell_tau == stratified Kendall's τ per paper §III.D definition.
    """
    grid = {c: {"t": [], "p": []} for c in cells}
    for i, m in enumerate(meta):
        key = (m["batch"], m["res"])
        if key in grid:
            grid[key]["t"].append(y_true[i]); grid[key]["p"].append(y_pred[i])

    per_cell = {}
    taus = []
    for k, v in grid.items():
        t = np.array(v["t"]); p = np.array(v["p"])
        if t.size < 2:
            per_cell[k] = (np.nan, np.nan); continue
        mape = mean_absolute_percentage_error(t, p) * 100
        tau, _ = kendalltau(t, p)
        per_cell[k] = (mape, tau if not np.isnan(tau) else np.nan)
        if not np.isnan(tau):
            taus.append(tau)

    overall_mape = mean_absolute_percentage_error(y_true, y_pred) * 100
    overall_r2   = r2_score(y_true, y_pred)
    mean_tau     = float(np.mean(taus)) if taus else np.nan
    return per_cell, overall_mape, overall_r2, mean_tau