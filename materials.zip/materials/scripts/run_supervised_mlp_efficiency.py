"""Matched-budget data-efficiency curve for the supervised architecture MLP.

The protocol uses the same 1,200/300 architecture-disjoint RTX 3090 split as
the official-HELP comparison.  For each repeat, the 1,200 training IDs are
permuted once and the budgets are nested prefixes.  Every selected architecture
contributes all 16 observed batch-by-quota labels.  Early stopping uses the
same deterministic 85/15 inner sample split as the controlled Table IV neural
baseline; the 300 outer test architectures are never used for training or
model selection.
"""

from __future__ import annotations

import argparse
import json
import pickle
import random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset


BUDGETS = (12, 22, 37, 62, 112, 212, 400, 800, 1200)
BATCHES = (1, 8, 16, 32)
QUOTAS = (10, 25, 50, 100)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def encode_arch(ks, expansion, depth) -> list[float]:
    feats = [d / 4.0 for d in depth]
    ks_onehot: list[float] = []
    e_onehot: list[float] = []
    ptr = 0
    for d in depth:
        for i in range(4):
            if i < d:
                kval, eval_ = ks[ptr + i], expansion[ptr + i]
                ks_onehot.extend(float(kval == x) for x in (3, 5, 7))
                e_onehot.extend(float(eval_ == x) for x in (3, 4, 6))
            else:
                ks_onehot.extend((0.0, 0.0, 0.0))
                e_onehot.extend((0.0, 0.0, 0.0))
        ptr += 4
    return feats + ks_onehot + e_onehot


class SupervisedArchMLP(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(127, 256),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(256, 256),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(256, 128),
            nn.GELU(),
            nn.Linear(128, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


def build_arrays(dataset):
    rows = []
    for arch_id, sample in enumerate(dataset):
        arch = encode_arch(sample["ks"], sample["e"], sample["d"])
        for batch in BATCHES:
            for quota in QUOTAS:
                latency = float(sample["latency_grid"][(batch, quota)])
                rows.append(
                    (
                        arch_id,
                        arch + [batch / 32.0, quota / 100.0],
                        np.log1p(latency),
                        latency,
                    )
                )
    ids = np.asarray([r[0] for r in rows], dtype=np.int32)
    x = np.asarray([r[1] for r in rows], dtype=np.float32)
    y_log = np.asarray([r[2] for r in rows], dtype=np.float32)
    y = np.asarray([r[3] for r in rows], dtype=np.float64)
    return ids, x, y_log, y


def fit_one(x_tr, y_tr, x_val, y_val, seed: int):
    set_seed(seed)
    device = torch.device("cpu")
    model = SupervisedArchMLP().to(device)
    train_ds = TensorDataset(torch.from_numpy(x_tr), torch.from_numpy(y_tr))
    loader = DataLoader(train_ds, batch_size=512, shuffle=True)
    vx = torch.from_numpy(x_val).to(device)
    vy = torch.from_numpy(y_val).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-5)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=200)
    best_mape = float("inf")
    best_state = None
    waited = 0
    best_epoch = 0
    for epoch in range(200):
        model.train()
        for xb, yb in loader:
            pred = model(xb.to(device))
            loss = F.huber_loss(pred, yb.to(device), delta=1.0)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
        sched.step()
        model.eval()
        with torch.no_grad():
            vp = model(vx).cpu().numpy()
        truth = np.expm1(vy.cpu().numpy())
        pred = np.expm1(vp)
        mape = float(np.mean(np.abs(pred - truth) / np.maximum(truth, 1e-12)) * 100)
        if mape < best_mape - 1e-3:
            best_mape = mape
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            waited = 0
            best_epoch = epoch + 1
        else:
            waited += 1
            if waited >= 20:
                break
    assert best_state is not None
    model.load_state_dict(best_state)
    return model, best_mape, best_epoch


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", type=Path, required=True)
    ap.add_argument("--official-help-predictions", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--repeats", type=int, default=5)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    with args.dataset.open("rb") as f:
        dataset = pickle.load(f)
    if len(dataset) != 1500:
        raise RuntimeError(f"Expected 1,500 architectures, found {len(dataset)}")
    pred_df = pd.read_csv(args.official_help_predictions)
    test_ids = np.sort(pred_df["arch_id"].unique().astype(int))
    if len(test_ids) != 300:
        raise RuntimeError(f"Expected 300 official-HELP test IDs, found {len(test_ids)}")
    train_ids = np.asarray(sorted(set(range(1500)) - set(test_ids)), dtype=np.int32)
    ids, x, y_log, y = build_arrays(dataset)
    test_mask = np.isin(ids, test_ids)
    x_test = torch.from_numpy(x[test_mask])
    y_test = y[test_mask]

    repeat_rows = []
    for repeat in range(args.repeats):
        outer_rng = np.random.RandomState(2026 + repeat)
        nested_ids = outer_rng.permutation(train_ids)
        for budget in BUDGETS:
            support = nested_ids[:budget]
            support_idx = np.flatnonzero(np.isin(ids, support))
            inner_rng = np.random.RandomState(2025)
            inner_idx = inner_rng.permutation(support_idx)
            n_val = max(1, int(0.15 * len(inner_idx)))
            val_idx = inner_idx[:n_val]
            fit_idx = inner_idx[n_val:]
            model, val_mape, best_epoch = fit_one(
                x[fit_idx], y_log[fit_idx], x[val_idx], y_log[val_idx],
                seed=2026 + 100 * repeat + budget,
            )
            model.eval()
            with torch.no_grad():
                pred = np.expm1(model(x_test).cpu().numpy())
            mape = float(np.mean(np.abs(pred - y_test) / np.maximum(y_test, 1e-12)) * 100)
            repeat_rows.append(
                {
                    "method": "Supervised architecture MLP",
                    "architectures_per_condition": budget,
                    "repeat": repeat,
                    "fit_samples": len(fit_idx),
                    "validation_samples": len(val_idx),
                    "target_labels": 16 * budget,
                    "mape_percent": mape,
                    "inner_val_mape_percent": val_mape,
                    "best_epoch": best_epoch,
                }
            )
            print(
                f"repeat={repeat} budget={budget} MAPE={mape:.4f}% "
                f"val={val_mape:.4f}% epoch={best_epoch}",
                flush=True,
            )

    repeat_df = pd.DataFrame(repeat_rows)
    repeat_df.to_csv(args.out / "repeat_metrics.csv", index=False)
    summary = (
        repeat_df.groupby("architectures_per_condition", as_index=False)
        .agg(
            runs=("repeat", "count"),
            mape_mean=("mape_percent", "mean"),
            mape_std=("mape_percent", "std"),
            mape_min=("mape_percent", "min"),
            mape_max=("mape_percent", "max"),
        )
    )
    summary.to_csv(args.out / "summary.csv", index=False)
    protocol = {
        "dataset": str(args.dataset),
        "outer_split": "300 test IDs recovered from official HELP predictions; complementary 1,200 IDs train only",
        "budgets": list(BUDGETS),
        "repeats": args.repeats,
        "nested_support_seed": "2026 + repeat",
        "inner_validation": "deterministic 85/15 sample split within each support set, matching the controlled Table IV neural baseline",
        "labels_per_architecture": 16,
        "model": "125-d flattened OFA-MBv3 one-hot encoding + normalized batch and scalar quota; 256-256-128 MLP",
        "training": "AdamW, Huber delta 1.0, cosine schedule, max 200 epochs, patience 20",
        "test_architectures": 300,
    }
    (args.out / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
