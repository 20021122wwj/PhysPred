"""Generate every manuscript figure from tabular experiment artifacts.

Run from the project root with::

    python scripts/generate_paper_figures.py

The script writes vector PDFs to ``figures/`` and compact, auditable CSVs to
``data/derived/``.  No panel is hand-edited after generation.
"""

from __future__ import annotations

from pathlib import Path
import json
import math

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DERIVED = DATA / "derived"
FIG = ROOT / "figures"
DERIVED.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

# Okabe--Ito palette: color-blind safe and legible in grayscale.
BLUE = "#0072B2"
ORANGE = "#E69F00"
GREEN = "#009E73"
VERMILION = "#D55E00"
PURPLE = "#CC79A7"
SKY = "#56B4E9"
GRAY = "#5F6368"
LIGHT = "#E9ECEF"

plt.rcParams.update({
    "font.family": "STIXGeneral",
    "mathtext.fontset": "stix",
    "font.size": 8.0,
    "axes.labelsize": 8.2,
    "axes.titlesize": 8.6,
    "legend.fontsize": 7.2,
    "xtick.labelsize": 7.2,
    "ytick.labelsize": 7.2,
    "axes.linewidth": 0.65,
    "lines.linewidth": 1.35,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "savefig.transparent": False,
    "savefig.dpi": 600,
})


def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(FIG / f"{stem}.pdf", bbox_inches="tight", pad_inches=0.025, dpi=600)
    fig.savefig(FIG / f"{stem}.png", dpi=360, bbox_inches="tight", pad_inches=0.025)
    plt.close(fig)


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(-0.10, 1.13, label, transform=ax.transAxes, fontweight="bold",
            fontsize=9, va="bottom")


def clean(ax: plt.Axes, axis: str = "y") -> None:
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(True, axis=axis, color="#C9CDD1", lw=0.45, alpha=0.55, zorder=0)


# ---------------------------------------------------------------------------
# Fig. 1: programmatic vector pipeline diagram.
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.12, 1.72))
ax.set_xlim(0, 13.55)
ax.set_ylim(0, 3.55)
ax.axis("off")

def box(x, y, w, h, title, sub, edge, face):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.06,rounding_size=0.08",
                       lw=0.9, ec=edge, fc=face)
    ax.add_patch(p)
    ax.text(x + w / 2, y + 0.69 * h, title, ha="center", va="center",
            fontweight="bold", color=edge, fontsize=6.1, linespacing=1.0)
    ax.text(x + w / 2, y + 0.22 * h, sub, ha="center", va="center",
            color="#333333", fontsize=5.6, linespacing=1.08)

def arrow(x1, y1, x2, y2):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                mutation_scale=8, lw=0.8, color=GRAY))

box(0.10, 1.22, 1.62, 0.96, "Architecture\nand $B,Q$",
    "candidate descriptor\noperating condition", BLUE, "#EAF4FA")
box(2.03, 1.22, 1.74, 0.96, "Stage-wise\ndecomposition",
    "pointwise / depthwise\ncomponent structure", BLUE, "#EAF4FA")
box(4.18, 2.06, 1.92, 0.90, "GPU representation",
    "Roofline coordinates\nallocated SMs", GREEN, "#E8F5F0")
box(4.18, 0.36, 1.92, 0.90, "CPU representation",
    "working set\nper active core", GREEN, "#E8F5F0")
box(6.58, 1.22, 1.72, 0.96, "Target-device\npredictor",
    "LightGBM-Huber\ngrouped training", BLUE, "#EAF4FA")
box(8.74, 1.22, 1.76, 0.96, "Residual safety\n(optional)",
    "disjoint 95th-percentile\ncalibration", PURPLE, "#FAEEF6")
box(10.94, 1.22, 2.20, 0.96, "Architecture–quota\nNAS",
    "enumerate feasible pairs\nmaximize accuracy", VERMILION, "#FCEEE8")
arrow(1.72, 1.70, 2.03, 1.70)
arrow(3.77, 1.70, 4.18, 2.51)
arrow(3.77, 1.70, 4.18, 0.81)
arrow(6.10, 2.51, 6.58, 1.84)
arrow(6.10, 0.81, 6.58, 1.56)
arrow(8.30, 1.70, 8.74, 1.70)
arrow(10.50, 1.70, 10.94, 1.70)
ax.text(0.10, 3.28, "Offline model construction", color=GRAY,
        fontsize=7.2, fontweight="bold")
ax.plot([0.10, 8.38], [3.17, 3.17], color="#B4B8BC", lw=0.6)
ax.text(8.74, 3.28, "Deployment controller", color=GRAY,
        fontsize=7.2, fontweight="bold")
ax.plot([8.74, 13.14], [3.17, 3.17], color="#B4B8BC", lw=0.6)
save(fig, "fig1_pipeline")


# ---------------------------------------------------------------------------
# Fig. 2: primary MBv3 results and operating-cell robustness.
# ---------------------------------------------------------------------------
overall = pd.DataFrame([
    ("RTX 3090", 3.06, 0.8635),
    ("AMD 4800H", 1.73, 0.8953),
    ("Intel 125H", 2.16, 0.8809),
], columns=["device", "mape_percent", "tau_stratified"])
overall.to_csv(DERIVED / "mbv3_overall.csv", index=False)

cell_specs = [
    ("RTX 3090", "gpu_holdout_per_cell.csv", [10, 25, 50, 100]),
    ("AMD 4800H", "amd_holdout_per_cell.csv", [25, 50, 100]),
    ("Intel 125H", "intel_holdout_per_cell.csv", [25, 50, 100]),
]
fig, axes = plt.subplots(1, 3, figsize=(7.12, 1.55),
                         gridspec_kw={"wspace": .34, "width_ratios": [1.18, 1, 1]})
for panel, (ax, (device, filename, quotas)) in enumerate(zip(axes, cell_specs)):
    cells = pd.read_csv(DATA / "local/operating_cells" / filename)
    cells.insert(0, "device", device)
    cells.to_csv(DERIVED / filename, index=False)
    arr = (cells.pivot(index="batch", columns="quota", values="mape_percent")
           .loc[[1, 8, 16, 32], quotas].to_numpy())
    im = ax.imshow(arr, cmap="YlOrRd", aspect="auto", vmin=1.0, vmax=4.25)
    ax.set_xticks(range(len(quotas)), quotas)
    ax.set_yticks(range(4), [1, 8, 16, 32])
    ax.set_xlabel("Quota (%)")
    ax.set_ylabel("Batch" if panel == 0 else "")
    ax.set_title(f"{device} MAPE (%)", pad=6, fontsize=7.8)
    for i in range(4):
        for j in range(len(quotas)):
            ax.text(j, i, f"{arr[i, j]:.2f}", ha="center", va="center",
                    fontsize=6.1, color="white" if arr[i, j] >= 2.8 else "black")
    panel_label(ax, f"({chr(ord('a') + panel)})")
cbar = fig.colorbar(im, ax=axes.ravel().tolist(), fraction=.024, pad=.022,
                    aspect=20, ticks=[1, 2, 3, 4])
cbar.set_label("Shared MAPE scale (%)", fontsize=7.2)
cbar.ax.tick_params(labelsize=6.8, length=2.2)
save(fig, "fig2_primary_results")


# ---------------------------------------------------------------------------
# Fig. 3: cumulative feature ablation. Adjacent changes are order-dependent.
# ---------------------------------------------------------------------------
ab_rows = [
    ("MBv3 GPU", 7.85, 3.39, 3.27, 3.06),
    ("MBv3 AMD", 3.24, 1.83, 1.67, 1.73),
    ("MBv3 Intel", 3.00, 2.25, 2.14, 2.16),
]
resnet = pd.read_csv(DATA / "server/revision_results/resnet_ablation_v2/summary.csv", header=[0, 1, 2])
resnet_vals = resnet.iloc[:, 3].astype(float).tolist() if len(resnet) == 4 else [4.861, 1.617, 1.402, 1.390]
# The multi-row header varies across pandas versions; validate, otherwise use
# the values printed in the source artifact.
if not (len(resnet_vals) == 4 and 1.0 < min(resnet_vals) < 5.0):
    resnet_vals = [4.861, 1.617, 1.402, 1.390]
ab_rows.append(("ResNet50", *resnet_vals))
ablation = pd.DataFrame(ab_rows, columns=["study", "A", "B", "C", "D"])
ablation.to_csv(DERIVED / "nested_ablation.csv", index=False)

fig, ax = plt.subplots(figsize=(3.52, 2.18))
xx = np.arange(4)
for (_, r), color, marker in zip(ablation.iterrows(), [BLUE, GREEN, ORANGE, VERMILION], ["o", "s", "^", "D"]):
    ax.plot(xx, r[["A", "B", "C", "D"]].astype(float), marker=marker, ms=4,
            color=color, label=r.study)
ax.set_xticks(xx, ["A\nFLOPs+Q", "B\n+stage", "C\n+traffic", "D\n+physical"])
ax.set_ylabel("MAPE (%)")
ax.set_ylim(1.0, 8.4)
clean(ax)
ax.legend(frameon=False, ncol=2, loc="upper right", handlelength=1.6)
save(fig, "fig3_nested_ablation")


# ---------------------------------------------------------------------------
# Fig. 4: scope, target-device calibration, and target-label efficiency.
# ---------------------------------------------------------------------------
jet = pd.read_csv(DATA / "server/revision_results/jet_ablation_v1/summary.csv")
jet_keep = jet[(jet.protocol == "mixed_quota_workload_group_5fold") & jet.method.isin([
    "Stagewise-ExplicitRoofline-LGBM", "Monolithic-ExplicitRoofline-LGBM",
    "Monolithic-WorkloadScalarQ-LGBM"])]
jet_keep[["method", "mape_mean", "mape_std"]].to_csv(DERIVED / "fixed_model_workload_mixed.csv", index=False)
transfer = pd.DataFrame([
    ("AMD to Intel", 0, 33.37), ("AMD to Intel", 10, 9.04),
    ("AMD to Intel", 25, 5.49), ("AMD to Intel", 50, 4.34),
    ("AMD to Intel", 100, 3.81), ("AMD to Intel", 200, 3.55),
    ("Intel to AMD", 0, 24.49), ("Intel to AMD", 10, 8.31),
    ("Intel to AMD", 25, 5.69), ("Intel to AMD", 50, 4.39),
    ("Intel to AMD", 100, 3.81), ("Intel to AMD", 200, 3.58),
], columns=["direction", "target_architectures", "mape_percent"])
transfer.to_csv(DERIVED / "cross_hardware_calibration.csv", index=False)

mlp_curve = pd.read_csv(DATA / "local/supervised_mlp_efficiency_curve" / "summary.csv")
help_curve = pd.DataFrame([
    (12, 20.778, 9.280), (22, 17.148, 7.083), (37, 15.999, 6.146),
    (62, 16.013, 5.209), (112, 15.454, 4.467), (212, 15.291, 4.007),
    (400, 12.736, 3.716), (800, 13.818, 3.360), (1200, 13.099, 3.194),
], columns=["architectures_per_condition", "official_help_mape", "physpred_mape"])
help_curve = help_curve.merge(
    mlp_curve[["architectures_per_condition", "mape_mean", "mape_std"]],
    on="architectures_per_condition", how="left"
).rename(columns={"mape_mean": "supervised_mlp_mape", "mape_std": "supervised_mlp_std"})
help_curve.to_csv(DERIVED / "official_help_physpred_supervised_curve.csv", index=False)

fig, (ax0, ax1, ax2) = plt.subplots(
    1, 3, figsize=(7.12, 1.68),
    gridspec_kw={"wspace": .48, "width_ratios": [1.0, 1.05, 1.12]})
labels = ["Stage", "Mono.-E", "Mono.-S"]
methods = ["Stagewise-ExplicitRoofline-LGBM", "Monolithic-ExplicitRoofline-LGBM", "Monolithic-WorkloadScalarQ-LGBM"]
vals = [float(jet_keep.loc[jet_keep.method == m, "mape_mean"].iloc[0]) for m in methods]
errs = [float(jet_keep.loc[jet_keep.method == m, "mape_std"].iloc[0]) for m in methods]
ax0.bar(np.arange(3), vals, yerr=errs, capsize=2, color=[BLUE, SKY, GRAY], width=.64, zorder=2)
ax0.set_xticks(np.arange(3), labels)
ax0.tick_params(axis="x", labelsize=6.4)
ax0.set_ylabel("Mixed-workload MAPE (%)")
ax0.set_title("Fixed-model workload")
for i, v in enumerate(vals): ax0.text(i, v + errs[i] + .35, f"{v:.3f}", ha="center", fontsize=7)
clean(ax0); panel_label(ax0, "(a)")

for direction, color, marker in [("AMD to Intel", BLUE, "o"), ("Intel to AMD", ORANGE, "s")]:
    r = transfer[transfer.direction == direction]
    ax1.plot(r.target_architectures, r.mape_percent, marker=marker, ms=4, color=color, label=direction)
ax1.set_yscale("log")
ax1.set_xticks([0, 25, 50, 100, 200])
ax1.set_yticks([3, 5, 10, 20, 40])
ax1.set_yticklabels(["3", "5", "10", "20", "40"])
ax1.minorticks_off()
ax1.set_xlabel("Target-device architectures")
ax1.set_ylabel("MAPE (%)")
ax1.set_title("Bidirectional CPU calibration")
clean(ax1, "both"); ax1.legend(frameon=False)
panel_label(ax1, "(b)")

ax2.plot(help_curve.architectures_per_condition, help_curve.official_help_mape,
         "o-", color=ORANGE, ms=3.4, label="Official HELP")
ax2.plot(help_curve.architectures_per_condition, help_curve.physpred_mape,
         "s-", color=BLUE, ms=3.2, label="Matched PhysPred")
ax2.plot(help_curve.architectures_per_condition, help_curve.supervised_mlp_mape,
         "^-", color=GREEN, ms=3.2, label="Sup. arch. MLP")
ax2.fill_between(help_curve.architectures_per_condition,
                 help_curve.supervised_mlp_mape-help_curve.supervised_mlp_std,
                 help_curve.supervised_mlp_mape+help_curve.supervised_mlp_std,
                 color=GREEN, alpha=.14, linewidth=0)
ax2.set_xscale("log"); ax2.set_yscale("log")
ax2.set_xticks([12, 37, 112, 400, 1200], [12, 37, 112, 400, 1200])
ax2.set_yticks([2, 4, 8, 16, 32, 64])
ax2.set_yticklabels(["2", "4", "8", "16", "32", "64"])
ax2.minorticks_off()
ax2.set_xlabel("Architectures/condition")
ax2.set_ylabel("MAPE (%)")
ax2.set_title("Target-label efficiency")
clean(ax2, "both"); ax2.legend(frameon=False, fontsize=5.8, handlelength=1.3,
                               loc="lower left")
panel_label(ax2, "(c)")
save(fig, "fig4_scope_transfer_efficiency")


# ---------------------------------------------------------------------------
# Additional derived data retained for the slowdown-factor audit.
# ---------------------------------------------------------------------------
slow = pd.DataFrame([
    (5, 22.432, 4.620), (10, 22.509, 4.506), (20, 22.425, 4.482),
    (50, 22.362, 4.436), (100, 22.346, 4.413),
], columns=["calibration_architectures", "slowdown_q_mape", "slowdown_bq_mape"])
slow.to_csv(DERIVED / "slowdown_curve.csv", index=False)

# ---------------------------------------------------------------------------
# Fig. 5: feature-to-counter validation, using final audited statistics.
# ---------------------------------------------------------------------------
counter = pd.DataFrame([
    ("GPU", "Intensity/ridge vs SM active", 0.513),
    ("GPU", "Intensity/ridge vs Tensor active", 0.628),
    ("GPU", "Intensity/ridge vs package power", 0.725),
    ("Intel", "WS/core vs latency (fixed cell)", 0.835),
    ("Intel", "Delta WS/core vs delta latency", 0.957),
    ("Intel", "Delta WS/core vs delta CPI", 0.813),
    ("AMD", "WS/core vs latency (fixed cell)", 0.891),
    ("AMD", "Delta WS/core vs delta latency", 0.971),
    ("AMD", "Intensity vs package power", 0.496),
], columns=["device", "relationship", "spearman_rho"])
counter.to_csv(DERIVED / "feature_counter_relationships.csv", index=False)
quota_changes = pd.DataFrame([
    ("GPU q100->q10", "Latency", 248.3), ("GPU q100->q10", "SM active", -76.1),
    ("GPU q100->q10", "Tensor active", -84.1), ("GPU q100->q10", "DRAM read", -47.8),
    ("GPU q100->q10", "DRAM write", -43.0),
    ("Intel q100->q25", "Latency", 160.1), ("Intel q100->q25", "Package power", -50.6),
    ("Intel q100->q25", "DRAM bandwidth", -41.2),
    ("AMD q100->q25", "Latency", 57.72), ("AMD q100->q25", "Package power", -54.90),
    ("AMD q100->q25", "Frequency", -0.0009),
], columns=["comparison", "metric", "median_change_percent"])
quota_changes.to_csv(DERIVED / "counter_quota_changes.csv", index=False)

fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(7.12, 1.55),
                               gridspec_kw={"width_ratios": [1.18, 1.32], "wspace": .50})
rel = counter.copy()
colors = rel.device.map({"GPU": BLUE, "Intel": ORANGE, "AMD": GREEN})
y = np.arange(len(rel))
ax0.barh(y, rel.spearman_rho, color=colors, height=.64, zorder=2)
short_rel = [
    "GPU: I/ridge to SM active", "I/ridge to Tensor active", "I/ridge to power",
    "Intel: WS/core to latency", r"$\Delta$WS/core to $\Delta$latency", r"$\Delta$WS/core to $\Delta$CPI",
    "AMD: WS/core to latency", r"$\Delta$WS/core to $\Delta$latency", "Intensity to power",
]
ax0.set_yticks(y, short_rel)
ax0.invert_yaxis(); ax0.set_xlim(0, 1.05)
ax0.set_xlabel(r"Descriptive Spearman $\rho$")
ax0.set_title("Feature-proxy association", fontsize=7.6, pad=4)
for yi, v in zip(y, rel.spearman_rho):
    ax0.text(v - .018, yi, f"{v:.3f}", va="center", ha="right",
             fontsize=6.6, color="white", fontweight="bold")
clean(ax0, "x"); panel_label(ax0, "(a)")

groups = list(quota_changes.comparison.unique())
y0 = 0
yt, yl = [], []
for g, gc in zip(groups, [BLUE, ORANGE, GREEN]):
    rr = quota_changes[quota_changes.comparison == g]
    yy = np.arange(y0, y0 + len(rr))
    ax1.barh(yy, rr.median_change_percent, color=[VERMILION if v > 0 else gc for v in rr.median_change_percent], height=.62, zorder=2)
    prefix = g.split()[0]
    labels = [f"{prefix}: {rr.metric.iloc[0]}"] + [f"    {m}" for m in rr.metric.iloc[1:]]
    yt.extend(yy); yl.extend(labels)
    y0 += len(rr) + 1
ax1.set_yticks(yt, yl); ax1.invert_yaxis(); ax1.axvline(0, color="#333", lw=.65)
ax1.set_xlim(-110, 275); ax1.set_xlabel("Median quota-paired change (%)")
ax1.set_title("Response to reduced allocation", fontsize=7.6, pad=4)
clean(ax1, "x"); panel_label(ax1, "(b)")
save(fig, "fig6_counter_validation")


# ---------------------------------------------------------------------------
# Fig. 7: accuracy predictor and complete HW-NAS decisions.
# ---------------------------------------------------------------------------
gnn = pd.DataFrame([
    ("Validation", "Spearman", 0.9884), ("Validation", "Kendall", 0.9066),
    ("Validation", "Pearson", 0.9924), ("300-arch OOD", "Spearman", 0.9327),
    ("300-arch OOD", "Kendall", 0.7700), ("300-arch OOD", "Pearson", 0.9248),
], columns=["split", "metric", "value"])
gnn.to_csv(DERIVED / "accuracy_predictor_validation.csv", index=False)
hwnas = pd.DataFrame([
    ("Full PhysPred", 3.018, .0332, .25, 70.31),
    ("Slowdown-BQ", 4.482, .0319, .75, 70.69),
    ("Slowdown-Q", 22.425, .0319, .75, 75.44),
    ("Official HELP-1200", 13.834, .0769, 3.50, 74.63),
    ("BRP-NAS", 11.307, .1407, 11.75, 65.81),
    ("FLOPs-only", 7.412, .1532, 1.50, 74.94),
    ("Official HELP-12", 20.430, .2121, 5.25, 72.38),
], columns=["method", "mape_percent", "auto_regret_pp", "violation_percent", "mean_quota_percent"])
hwnas.to_csv(DERIVED / "automatic_quota_hwnas_n20.csv", index=False)


print("Generated the current manuscript vector figures in", FIG)
